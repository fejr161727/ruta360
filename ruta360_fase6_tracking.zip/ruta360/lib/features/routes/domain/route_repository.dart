import 'route_model.dart';

abstract class RouteRepository {
  /// Crea la ruta y devuelve su id.
  Future<String> create(RouteModel route);

  Future<List<RouteModel>> publicRoutes({int limit = 100});

  Future<List<RouteModel>> myRoutes(String uid, {int limit = 100});

  Future<RouteModel?> byId(String id);

  Future<void> delete(String id);
}
