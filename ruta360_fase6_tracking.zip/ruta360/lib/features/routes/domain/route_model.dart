import 'package:equatable/equatable.dart';

import '../../../core/constants/activity_type.dart';
import '../../../core/constants/route_enums.dart';
import '../../../core/utils/geo_utils.dart';

class RouteModel extends Equatable {
  const RouteModel({
    required this.id,
    required this.ownerId,
    required this.ownerName,
    required this.name,
    required this.description,
    required this.activity,
    required this.difficulty,
    required this.surface,
    required this.distanceMeters,
    required this.ascentMeters,
    required this.points,
    required this.visibility,
    this.createdAt,
  });

  final String id;
  final String ownerId;
  final String ownerName;
  final String name;
  final String description;
  final ActivityType activity;
  final Difficulty difficulty;
  final Surface surface;
  final double distanceMeters;
  final double ascentMeters;
  final List<GeoPoint> points;
  final ContentVisibility visibility;
  final DateTime? createdAt;

  GeoPoint get start => points.first;
  GeoPoint get end => points.last;
  bool get isPublic => visibility == ContentVisibility.public;

  int get estimatedMinutes =>
      (distanceMeters / 1000 / activity.nominalSpeedKmh * 60).round();

  @override
  List<Object?> get props => [
        id,
        ownerId,
        name,
        description,
        activity,
        difficulty,
        surface,
        distanceMeters,
        ascentMeters,
        visibility,
        createdAt,
      ];
}
