import 'app_user.dart';

abstract class AuthRepository {
  /// Emite el usuario actual (o null) y cada cambio de sesión/perfil.
  Stream<AppUser?> authStateChanges();

  Future<void> signIn({required String email, required String password});

  Future<void> register({
    required String email,
    required String password,
    required String displayName,
  });

  Future<void> sendPasswordReset(String email);

  Future<void> signOut();
}
