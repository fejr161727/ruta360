import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/errors/app_failure.dart';
import '../../../core/router/app_router.dart';
import '../../../core/utils/geo_utils.dart';
import '../../../shared/widgets/async_error_view.dart';
import '../../../shared/widgets/empty_state.dart';
import '../../maps/domain/location_service.dart';
import '../../maps/presentation/location_providers.dart';
import '../../maps/presentation/map_defaults.dart';
import '../../maps/presentation/widgets/ruta_map_view.dart';
import '../../routes/domain/route_filters.dart';
import '../../routes/domain/route_model.dart';
import '../../routes/presentation/route_filters_provider.dart';
import '../../routes/presentation/routes_providers.dart';
import '../../routes/presentation/widgets/route_card.dart';
import '../../routes/presentation/widgets/route_filter_sheet.dart';

class ExploreScreen extends ConsumerStatefulWidget {
  const ExploreScreen({super.key});

  @override
  ConsumerState<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends ConsumerState<ExploreScreen> {
  final _map = RutaMapController();
  GeoPoint? _position;
  AppFailure? _failure;
  bool _loading = false;
  bool _showMap = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _locate());
  }

  @override
  void dispose() {
    _map.dispose();
    super.dispose();
  }

  Future<void> _locate() async {
    if (_loading) return;
    setState(() {
      _loading = true;
      _failure = null;
    });
    try {
      final p = await ref.read(locationServiceProvider).currentPosition();
      if (!mounted) return;
      setState(() => _position = p);
      _map.moveTo(p, zoom: 14);
    } on AppFailure catch (e) {
      if (mounted) setState(() => _failure = e);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _openFilters() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => const RouteFilterSheet(),
    );
  }

  Future<void> _refresh() async {
    ref.invalidate(exploreRoutesProvider);
    try {
      await ref.read(exploreRoutesProvider.future);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final routesAsync = ref.watch(exploreRoutesProvider);
    final filters = ref.watch(routeFiltersProvider);
    final all = routesAsync.valueOrNull ?? const [];
    final routes = applyRouteFilters(all, filters, userPosition: _position);

    return Scaffold(
      appBar: AppBar(title: const Text('Explorar')),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          FloatingActionButton.small(
            heroTag: 'explore_locate',
            tooltip: 'Mi ubicación',
            onPressed: _loading ? null : _locate,
            child: _loading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.my_location),
          ),
          const SizedBox(height: 12),
          FloatingActionButton.extended(
            heroTag: 'explore_new_route',
            onPressed: () => context.push(AppRoutes.routeNew),
            icon: const Icon(Icons.add_road),
            label: const Text('Crear ruta'),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
            child: TextField(
              onChanged: (v) => ref
                  .read(routeFiltersProvider.notifier)
                  .update((f) => f.copyWith(query: v)),
              decoration: InputDecoration(
                hintText: 'Buscar rutas por nombre',
                prefixIcon: const Icon(Icons.search),
                isDense: true,
                suffixIcon: IconButton(
                  tooltip: 'Filtros',
                  onPressed: _openFilters,
                  icon: Badge(
                    isLabelVisible: filters.hasActive,
                    child: const Icon(Icons.tune),
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
            child: Row(
              children: [
                SegmentedButton<bool>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(
                        value: true,
                        icon: Icon(Icons.map_outlined),
                        label: Text('Mapa')),
                    ButtonSegment(
                        value: false,
                        icon: Icon(Icons.view_list_outlined),
                        label: Text('Lista')),
                  ],
                  selected: {_showMap},
                  onSelectionChanged: (s) =>
                      setState(() => _showMap = s.first),
                ),
                const Spacer(),
                Text(
                  routesAsync.isLoading
                      ? 'Cargando…'
                      : '${routes.length} ruta${routes.length == 1 ? '' : 's'}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          Expanded(
            child: _showMap
                ? _buildMap(routes, routesAsync)
                : _buildList(routes, routesAsync),
          ),
        ],
      ),
    );
  }

  Widget _buildMap(List<RouteModel> routes, AsyncValue<List<RouteModel>> routesAsync) {
    final failure = _failure;
    return Stack(
      children: [
        RutaMapView(
          controller: _map,
          center: _position ?? kDefaultMapCenter,
          zoom: _position == null ? 12 : 14,
          userLocation: _position,
          markers: [
            for (final r in routes)
              MapMarkerData(
                point: r.start,
                onTap: () => context.push(AppRoutes.routeDetail(r.id)),
              ),
          ],
        ),
        if (failure != null)
          Positioned(
            left: 12,
            right: 12,
            top: 8,
            child: _LocationBanner(
              failure: failure,
              onRetry: _locate,
              onOpenSettings: failure is LocationFailure &&
                      (failure.issue == LocationIssue.serviceDisabled ||
                          failure.issue == LocationIssue.deniedForever)
                  ? () => ref
                      .read(locationServiceProvider)
                      .openSettings(failure.issue)
                  : null,
            ),
          )
        else if (routesAsync.hasError)
          Positioned(
            left: 12,
            right: 12,
            top: 8,
            child: Card(
              child: ListTile(
                leading: const Icon(Icons.cloud_off_outlined),
                title: Text(routesAsync.error is AppFailure
                    ? (routesAsync.error as AppFailure).message
                    : 'No se pudieron cargar las rutas.'),
                trailing: TextButton(
                    onPressed: _refresh, child: const Text('Reintentar')),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildList(List<RouteModel> routes, AsyncValue<List<RouteModel>> routesAsync) {
    if (routesAsync.isLoading && routes.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (routesAsync.hasError && routes.isEmpty) {
      return AsyncErrorView(error: routesAsync.error!, onRetry: _refresh);
    }
    if (routes.isEmpty) {
      return const EmptyState(
        icon: Icons.route_outlined,
        title: 'Aún no hay rutas',
        message:
            'Crea la primera con el botón "Crear ruta" o ajusta los filtros.',
      );
    }
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView.builder(
        padding: const EdgeInsets.only(bottom: 160),
        itemCount: routes.length,
        itemBuilder: (context, i) {
          final r = routes[i];
          return RouteCard(
            route: r,
            distanceFromUserM: _position == null
                ? null
                : GeoUtils.distanceMeters(_position!, r.start),
            onTap: () => context.push(AppRoutes.routeDetail(r.id)),
          );
        },
      ),
    );
  }
}

class _LocationBanner extends StatelessWidget {
  const _LocationBanner({
    required this.failure,
    required this.onRetry,
    this.onOpenSettings,
  });

  final AppFailure failure;
  final VoidCallback onRetry;
  final VoidCallback? onOpenSettings;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.location_off_outlined),
                const SizedBox(width: 8),
                Expanded(child: Text(failure.message)),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                if (onOpenSettings != null)
                  TextButton(
                    onPressed: onOpenSettings,
                    child: const Text('Abrir ajustes'),
                  ),
                TextButton(onPressed: onRetry, child: const Text('Reintentar')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
