import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/router/app_router.dart';
import '../../../shared/widgets/async_error_view.dart';
import '../../../shared/widgets/empty_state.dart';
import '../../auth/presentation/auth_providers.dart';
import '../domain/route_filters.dart';
import 'routes_providers.dart';
import 'widgets/route_card.dart';

class MyRoutesScreen extends ConsumerWidget {
  const MyRoutesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final uid = ref.watch(authStateProvider).valueOrNull?.uid;
    final async = ref.watch(exploreRoutesProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Mis rutas')),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => AsyncErrorView(
          error: e,
          onRetry: () => ref.invalidate(exploreRoutesProvider),
        ),
        data: (all) {
          final mine = applyRouteFilters(
            all.where((r) => r.ownerId == uid).toList(),
            const RouteFilters(),
          );
          if (mine.isEmpty) {
            return const EmptyState(
              icon: Icons.route_outlined,
              title: 'Aún no tienes rutas',
              message: 'Crea una desde Explorar → Crear ruta.',
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: 8),
            itemCount: mine.length,
            itemBuilder: (_, i) => RouteCard(
              route: mine[i],
              onTap: () => context.push(AppRoutes.routeDetail(mine[i].id)),
            ),
          );
        },
      ),
    );
  }
}
