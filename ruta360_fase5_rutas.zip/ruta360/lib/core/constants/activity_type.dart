import 'package:flutter/material.dart';

enum ActivityType {
  cycling('cycling', 'Bicicleta', Icons.directions_bike),
  mtb('mtb', 'MTB', Icons.terrain),
  gravel('gravel', 'Gravel', Icons.pedal_bike),
  road('road', 'Ciclismo de ruta', Icons.directions_bike_outlined),
  running('running', 'Running', Icons.directions_run),
  walking('walking', 'Caminata', Icons.directions_walk),
  trekking('trekking', 'Trekking', Icons.hiking),
  moto('moto', 'Moto', Icons.two_wheeler);

  const ActivityType(this.id, this.label, this.icon);

  final String id;
  final String label;
  final IconData icon;

  static ActivityType fromId(String id) => ActivityType.values
      .firstWhere((e) => e.id == id, orElse: () => ActivityType.cycling);
}

extension ActivityTypeSpeed on ActivityType {
  /// Velocidad media típica, solo para estimar el tiempo de una ruta.
  double get nominalSpeedKmh => switch (this) {
        ActivityType.cycling => 18,
        ActivityType.mtb => 14,
        ActivityType.gravel => 17,
        ActivityType.road => 26,
        ActivityType.running => 9,
        ActivityType.walking => 4.5,
        ActivityType.trekking => 3.5,
        ActivityType.moto => 45,
      };
}
