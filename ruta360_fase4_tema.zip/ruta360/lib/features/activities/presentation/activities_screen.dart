import 'package:flutter/material.dart';
import '../../../shared/widgets/empty_state.dart';

class ActivitiesScreen extends StatelessWidget {
  const ActivitiesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Registrar')),
      body: const EmptyState(
        icon: Icons.add_circle_outline,
        title: 'Registrar',
        message: 'El registro GPS de actividades llega en la Fase 6.',
      ),
    );
  }
}
