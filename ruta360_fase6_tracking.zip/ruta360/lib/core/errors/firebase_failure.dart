import 'package:firebase_core/firebase_core.dart';

import 'app_failure.dart';

AppFailure firebaseFailure(FirebaseException e) {
  switch (e.code) {
    case 'permission-denied':
      return const AppFailure('No tienes permiso para realizar esta acción.');
    case 'unavailable':
    case 'deadline-exceeded':
      return const AppFailure(
          'Sin conexión. Revisa tu internet e intenta de nuevo.');
    default:
      return AppFailure('No se pudo completar la operación (${e.code}).');
  }
}
