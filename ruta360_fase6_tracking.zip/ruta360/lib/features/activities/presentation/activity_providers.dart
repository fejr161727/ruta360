import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../auth/presentation/auth_providers.dart';
import '../data/firestore_activity_repository.dart';
import '../domain/activity_model.dart';
import '../domain/activity_repository.dart';

final activityRepositoryProvider = Provider<ActivityRepository>(
  (ref) => FirestoreActivityRepository(),
);

final myActivitiesProvider =
    FutureProvider.autoDispose<List<ActivityModel>>((ref) async {
  final uid = ref.watch(authStateProvider.select((a) => a.valueOrNull?.uid));
  if (uid == null) return const [];
  final list = await ref.watch(activityRepositoryProvider).myActivities(uid);
  list.sort((a, b) => b.startedAt.compareTo(a.startedAt));
  return list;
});

final activityByIdProvider =
    FutureProvider.autoDispose.family<ActivityModel?, String>((ref, id) {
  return ref.watch(activityRepositoryProvider).byId(id);
});
