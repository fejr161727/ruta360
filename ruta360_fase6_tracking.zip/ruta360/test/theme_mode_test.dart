import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ruta360/core/theme/theme_mode_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  Future<ProviderContainer> makeContainer(Map<String, Object> initial) async {
    SharedPreferences.setMockInitialValues(initial);
    final prefs = await SharedPreferences.getInstance();
    return ProviderContainer(
      overrides: [sharedPreferencesProvider.overrideWithValue(prefs)],
    );
  }

  test('abre en modo claro por defecto', () async {
    final c = await makeContainer({});
    addTearDown(c.dispose);
    expect(c.read(themeModeProvider), ThemeMode.light);
  });

  test('guarda y recupera el modo oscuro', () async {
    final c = await makeContainer({});
    addTearDown(c.dispose);
    await c.read(themeModeProvider.notifier).setMode(ThemeMode.dark);
    expect(c.read(themeModeProvider), ThemeMode.dark);

    final c2 = await makeContainer({'theme_mode': 'dark'});
    addTearDown(c2.dispose);
    expect(c2.read(themeModeProvider), ThemeMode.dark);
  });
}
