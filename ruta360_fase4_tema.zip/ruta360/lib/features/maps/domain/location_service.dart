import '../../../core/errors/app_failure.dart';
import '../../../core/utils/geo_utils.dart';

enum LocationIssue { serviceDisabled, denied, deniedForever, unavailable }

class LocationFailure extends AppFailure {
  const LocationFailure(this.issue, super.message);
  final LocationIssue issue;
}

abstract class LocationService {
  /// Obtiene la posición actual. Lanza [LocationFailure] si no es posible.
  Future<GeoPoint> currentPosition();

  /// Abre los ajustes del sistema apropiados para resolver [issue].
  Future<void> openSettings(LocationIssue issue);
}
