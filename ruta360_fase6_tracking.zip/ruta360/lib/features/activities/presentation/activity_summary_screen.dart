import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/constants/route_enums.dart';
import '../../../core/errors/app_failure.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/geo_utils.dart';
import '../../../shared/widgets/empty_state.dart';
import '../../auth/presentation/auth_providers.dart';
import '../../maps/presentation/widgets/ruta_map_view.dart';
import '../../routes/domain/route_model.dart';
import '../../routes/presentation/routes_providers.dart';
import '../domain/activity_model.dart';
import 'activity_providers.dart';
import 'tracker_notifier.dart';
import 'widgets/activity_stats.dart';

class ActivitySummaryScreen extends ConsumerStatefulWidget {
  const ActivitySummaryScreen({super.key});

  @override
  ConsumerState<ActivitySummaryScreen> createState() =>
      _ActivitySummaryScreenState();
}

class _ActivitySummaryScreenState extends ConsumerState<ActivitySummaryScreen> {
  final _map = RutaMapController();
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _title;
  final _description = TextEditingController();
  Difficulty _difficulty = Difficulty.moderate;
  Surface _surface = Surface.mixed;
  ContentVisibility _visibility = ContentVisibility.private;
  bool _hideEnds = true;
  bool _alsoRoute = false;
  bool _saving = false;

  static const double _hideMeters = 200;

  @override
  void initState() {
    super.initState();
    final t = ref.read(trackerProvider);
    final started = t.startedAt ?? DateTime.now();
    _title = TextEditingController(
        text: '${t.type.label} · ${Fmt.date(started)}');
    _map.fitTo(t.points, padding: 40);
  }

  @override
  void dispose() {
    _map.dispose();
    _title.dispose();
    _description.dispose();
    super.dispose();
  }

  List<GeoPoint> _publishedPoints(List<GeoPoint> raw) {
    final isPublic = _visibility == ContentVisibility.public;
    return (isPublic && _hideEnds) ? GeoUtils.trimEnds(raw, _hideMeters) : raw;
  }

  Future<void> _discard() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Descartar actividad'),
        content: const Text('Se perderá el recorrido registrado.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar')),
          FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Descartar')),
        ],
      ),
    );
    if (ok != true) return;
    ref.read(trackerProvider.notifier).reset();
    if (mounted) context.pop();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final t = ref.read(trackerProvider);
    final user = ref.read(authStateProvider).valueOrNull;
    if (user == null) return;
    final messenger = ScaffoldMessenger.of(context);
    setState(() => _saving = true);
    try {
      final ownerName = (user.displayName?.trim().isNotEmpty ?? false)
          ? user.displayName!.trim()
          : user.email.split('@').first;
      final published = _publishedPoints(t.points);
      final activity = ActivityModel(
        id: '',
        ownerId: user.uid,
        ownerName: ownerName,
        type: t.type,
        title: _title.text,
        description: _description.text,
        distanceMeters: t.distanceM,
        movingSeconds: t.elapsed.inSeconds,
        avgSpeedMps: t.avgSpeedMps,
        maxSpeedMps: t.maxSpeedMps,
        ascentMeters: t.ascentM,
        descentMeters: t.descentM,
        calories: t.calories,
        difficulty: _difficulty,
        surface: _surface,
        visibility: _visibility,
        startedAt: t.startedAt ?? DateTime.now(),
        points: published,
        routeId: t.routeId,
      );

      var queued = false;
      try {
        await ref
            .read(activityRepositoryProvider)
            .create(activity)
            .timeout(const Duration(seconds: 12));
        if (_alsoRoute && published.length >= 2) {
          await ref
              .read(routeRepositoryProvider)
              .create(RouteModel(
                id: '',
                ownerId: user.uid,
                ownerName: ownerName,
                name: _title.text,
                description: _description.text,
                activity: t.type,
                difficulty: _difficulty,
                surface: _surface,
                distanceMeters: GeoUtils.polylineLengthMeters(published),
                ascentMeters: t.ascentM,
                points: published,
                visibility: _visibility,
              ))
              .timeout(const Duration(seconds: 12));
        }
      } on TimeoutException {
        queued = true;
      }

      ref.invalidate(myActivitiesProvider);
      ref.invalidate(exploreRoutesProvider);
      ref.read(trackerProvider.notifier).reset();
      messenger.showSnackBar(SnackBar(
        content: Text(queued
            ? 'Sin conexión: se enviará cuando vuelva internet.'
            : 'Actividad guardada.'),
      ));
      if (mounted) context.pop();
    } on AppFailure catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = ref.watch(trackerProvider);
    if (t.status != TrackerStatus.finished) {
      return Scaffold(
        appBar: AppBar(title: const Text('Resumen')),
        body: const EmptyState(
          icon: Icons.check_circle_outline,
          title: 'Nada por guardar',
          message: 'Termina una actividad en la pestaña Registrar.',
        ),
      );
    }

    final isPublic = _visibility == ContentVisibility.public;
    final publishedPoints = _publishedPoints(t.points);
    final tooShortToHide = isPublic && _hideEnds && publishedPoints.length < 2;

    return Scaffold(
      appBar: AppBar(title: const Text('Resumen de la actividad')),
      body: ListView(
        children: [
          SizedBox(
            height: 240,
            child: RutaMapView(
              controller: _map,
              center: t.points.isNotEmpty ? t.points.first : const GeoPoint(0, 0),
              zoom: 14,
              polylines: [MapPolylineData(points: t.points)],
              markers: [
                if (t.points.length >= 2)
                  MapMarkerData(
                      point: t.points.first,
                      icon: Icons.trip_origin,
                      color: Colors.green,
                      size: 24,
                      centered: true),
                if (t.points.length >= 2)
                  MapMarkerData(
                      point: t.points.last,
                      icon: Icons.location_on,
                      color: Colors.red),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  ActivityStats(
                    type: t.type,
                    distanceM: t.distanceM,
                    elapsed: t.elapsed,
                    avgSpeedMps: t.avgSpeedMps,
                    maxSpeedMps: t.maxSpeedMps,
                    ascentM: t.ascentM,
                    calories: t.calories,
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    controller: _title,
                    maxLength: 80,
                    decoration: const InputDecoration(labelText: 'Título'),
                    validator: (v) => (v == null || v.trim().length < 3)
                        ? 'Escribe un título (mínimo 3 letras)'
                        : null,
                  ),
                  const SizedBox(height: 8),
                  TextFormField(
                    controller: _description,
                    maxLines: 3,
                    maxLength: 500,
                    decoration: const InputDecoration(
                        labelText: 'Descripción (opcional)',
                        alignLabelWithHint: true),
                  ),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<Difficulty>(
                    value: _difficulty,
                    decoration: const InputDecoration(labelText: 'Dificultad'),
                    items: [
                      for (final d in Difficulty.values)
                        DropdownMenuItem(value: d, child: Text(d.label)),
                    ],
                    onChanged: (v) =>
                        setState(() => _difficulty = v ?? _difficulty),
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<Surface>(
                    value: _surface,
                    decoration: const InputDecoration(labelText: 'Superficie'),
                    items: [
                      for (final s in Surface.values)
                        DropdownMenuItem(value: s, child: Text(s.label)),
                    ],
                    onChanged: (v) => setState(() => _surface = v ?? _surface),
                  ),
                  const SizedBox(height: 16),
                  SegmentedButton<ContentVisibility>(
                    segments: const [
                      ButtonSegment(
                          value: ContentVisibility.private,
                          icon: Icon(Icons.lock_outline),
                          label: Text('Privada')),
                      ButtonSegment(
                          value: ContentVisibility.public,
                          icon: Icon(Icons.public),
                          label: Text('Pública')),
                    ],
                    selected: {_visibility},
                    onSelectionChanged: (s) =>
                        setState(() => _visibility = s.first),
                  ),
                  if (isPublic)
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Ocultar inicio y fin'),
                      subtitle: const Text(
                          'No publica los primeros y últimos 200 m (por ejemplo, tu casa).'),
                      value: _hideEnds,
                      onChanged: (v) => setState(() => _hideEnds = v),
                    ),
                  if (tooShortToHide)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Text(
                        'El recorrido es muy corto para ocultar inicio y fin: '
                        'se guardará sin trazado en el mapa.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.leading,
                    title: const Text('Guardar también como ruta'),
                    subtitle: const Text('Aparecerá en Explorar y Mis rutas.'),
                    value: _alsoRoute && publishedPoints.length >= 2,
                    onChanged: publishedPoints.length >= 2
                        ? (v) => setState(() => _alsoRoute = v ?? false)
                        : null,
                  ),
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: _saving ? null : _save,
                    child: _saving
                        ? const SizedBox(
                            height: 22,
                            width: 22,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('Guardar actividad'),
                  ),
                  TextButton(
                    onPressed: _saving ? null : _discard,
                    child: const Text('Descartar'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
