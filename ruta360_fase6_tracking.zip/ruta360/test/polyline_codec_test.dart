import 'package:flutter_test/flutter_test.dart';
import 'package:ruta360/core/utils/geo_utils.dart';
import 'package:ruta360/core/utils/polyline_codec.dart';

void main() {
  const sample = [
    GeoPoint(38.5, -120.2),
    GeoPoint(40.7, -120.95),
    GeoPoint(43.252, -126.453),
  ];

  test('codifica igual que el ejemplo oficial de Google', () {
    expect(PolylineCodec.encode(sample), '_p~iF~ps|U_ulLnnqC_mqNvxq`@');
  });

  test('decodifica el ejemplo oficial', () {
    final pts = PolylineCodec.decode('_p~iF~ps|U_ulLnnqC_mqNvxq`@');
    expect(pts.length, 3);
    expect(pts[0].lat, closeTo(38.5, 1e-5));
    expect(pts[2].lng, closeTo(-126.453, 1e-5));
  });

  test('ida y vuelta conserva los puntos (Quito)', () {
    const quito = [
      GeoPoint(-0.18065, -78.46783),
      GeoPoint(-0.18102, -78.46644),
      GeoPoint(-0.17977, -78.46512),
    ];
    final back = PolylineCodec.decode(PolylineCodec.encode(quito));
    for (var i = 0; i < quito.length; i++) {
      expect(back[i].lat, closeTo(quito[i].lat, 1e-5));
      expect(back[i].lng, closeTo(quito[i].lng, 1e-5));
    }
  });

  test('texto vacío da lista vacía', () {
    expect(PolylineCodec.decode(''), isEmpty);
  });
}
