import '../../../core/utils/geo_utils.dart';

class TrackPoint {
  const TrackPoint({
    required this.lat,
    required this.lng,
    required this.time,
    this.altitude,
    this.speedMps,
    this.accuracy,
  });

  final double lat;
  final double lng;
  final DateTime time;
  final double? altitude;
  final double? speedMps;
  final double? accuracy;

  GeoPoint get geo => GeoPoint(lat, lng);
}
