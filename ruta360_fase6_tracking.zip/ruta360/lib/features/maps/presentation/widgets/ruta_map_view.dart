import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../../../../core/config/env.dart';
import '../../../../core/utils/geo_utils.dart';

class MapMarkerData {
  const MapMarkerData({
    required this.point,
    this.color,
    this.icon = Icons.place,
    this.size = 40,
    this.centered = false,
    this.onTap,
  });

  final GeoPoint point;
  final Color? color;
  final IconData icon;
  final double size;

  /// true: el icono se centra en el punto (círculos); false: la punta del pin.
  final bool centered;
  final VoidCallback? onTap;
}

class MapPolylineData {
  const MapPolylineData({
    required this.points,
    this.color = const Color(0xFFFF6B2C),
    this.width = 5,
  });

  final List<GeoPoint> points;
  final Color color;
  final double width;
}

/// Controlador propio: la app no depende del tipo de controlador del proveedor.
class RutaMapController {
  final MapController _inner = MapController();
  bool _ready = false;
  (GeoPoint, double?)? _pendingMove;
  (List<GeoPoint>, double)? _pendingFit;

  void _onReady() {
    _ready = true;
    final fit = _pendingFit;
    final move = _pendingMove;
    _pendingFit = null;
    _pendingMove = null;
    if (fit != null) {
      fitTo(fit.$1, padding: fit.$2);
    } else if (move != null) {
      moveTo(move.$1, zoom: move.$2);
    }
  }

  void moveTo(GeoPoint point, {double? zoom}) {
    if (!_ready) {
      _pendingMove = (point, zoom);
      return;
    }
    _inner.move(LatLng(point.lat, point.lng), zoom ?? _inner.camera.zoom);
  }

  /// Encuadra todos los puntos en pantalla.
  void fitTo(List<GeoPoint> points, {double padding = 48}) {
    if (points.isEmpty) return;
    if (points.length == 1 || GeoUtils.polylineLengthMeters(points) < 5) {
      moveTo(points.first, zoom: 16);
      return;
    }
    if (!_ready) {
      _pendingFit = (points, padding);
      return;
    }
    _inner.fitCamera(
      CameraFit.bounds(
        bounds: LatLngBounds.fromPoints(
          [for (final p in points) LatLng(p.lat, p.lng)],
        ),
        padding: EdgeInsets.all(padding),
      ),
    );
  }

  void dispose() => _inner.dispose();
}

class RutaMapView extends StatelessWidget {
  const RutaMapView({
    super.key,
    required this.controller,
    required this.center,
    this.zoom = 13,
    this.userLocation,
    this.markers = const [],
    this.polylines = const [],
    this.onTap,
  });

  final RutaMapController controller;
  final GeoPoint center;
  final double zoom;
  final GeoPoint? userLocation;
  final List<MapMarkerData> markers;
  final List<MapPolylineData> polylines;
  final void Function(GeoPoint point)? onTap;

  @override
  Widget build(BuildContext context) {
    final lines = [
      for (final p in polylines)
        if (p.points.length >= 2) p,
    ];
    return FlutterMap(
      mapController: controller._inner,
      options: MapOptions(
        initialCenter: LatLng(center.lat, center.lng),
        initialZoom: zoom,
        minZoom: 3,
        maxZoom: 19,
        onMapReady: controller._onReady,
        onTap: onTap == null
            ? null
            : (tapPosition, latLng) =>
                onTap!(GeoPoint(latLng.latitude, latLng.longitude)),
      ),
      children: [
        TileLayer(
          urlTemplate: Env.tileUrlTemplate,
          userAgentPackageName: Env.androidPackage,
        ),
        if (lines.isNotEmpty)
          PolylineLayer(
            polylines: [
              for (final p in lines)
                Polyline(
                  points: [for (final g in p.points) LatLng(g.lat, g.lng)],
                  color: p.color,
                  strokeWidth: p.width,
                ),
            ],
          ),
        if (markers.isNotEmpty)
          MarkerLayer(
            markers: [
              for (final m in markers)
                Marker(
                  point: LatLng(m.point.lat, m.point.lng),
                  width: m.size,
                  height: m.size,
                  alignment: m.centered ? Alignment.center : Alignment.topCenter,
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: m.onTap,
                    child: Icon(
                      m.icon,
                      size: m.size,
                      color: m.color ?? Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
            ],
          ),
        if (userLocation != null)
          MarkerLayer(
            markers: [
              Marker(
                point: LatLng(userLocation!.lat, userLocation!.lng),
                width: 22,
                height: 22,
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E88E5),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 3),
                    boxShadow: const [
                      BoxShadow(blurRadius: 6, color: Colors.black38),
                    ],
                  ),
                ),
              ),
            ],
          ),
        RichAttributionWidget(
          attributions: [TextSourceAttribution(Env.tileAttribution)],
        ),
      ],
    );
  }
}
