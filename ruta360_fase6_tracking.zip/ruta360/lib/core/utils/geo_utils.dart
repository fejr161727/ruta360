import 'dart:math' as math;

class GeoPoint {
  const GeoPoint(this.lat, this.lng);
  final double lat;
  final double lng;
}

class GeoUtils {
  const GeoUtils._();

  static const double _earthRadiusM = 6371008.8;

  /// Distancia Haversine en metros entre dos puntos.
  static double distanceMeters(GeoPoint a, GeoPoint b) {
    final dLat = _rad(b.lat - a.lat);
    final dLng = _rad(b.lng - a.lng);
    final h = math.pow(math.sin(dLat / 2), 2) +
        math.cos(_rad(a.lat)) *
            math.cos(_rad(b.lat)) *
            math.pow(math.sin(dLng / 2), 2);
    return 2 * _earthRadiusM * math.asin(math.min(1.0, math.sqrt(h)));
  }

  /// Longitud total de una polilínea en metros.
  static double polylineLengthMeters(List<GeoPoint> points) {
    var total = 0.0;
    for (var i = 1; i < points.length; i++) {
      total += distanceMeters(points[i - 1], points[i]);
    }
    return total;
  }

  /// Quita el inicio y el final del recorrido (privacidad): descarta los
  /// puntos a menos de [meters] del principio y del final. Si el recorrido es
  /// demasiado corto para ocultarlos, devuelve una lista vacía.
  static List<GeoPoint> trimEnds(List<GeoPoint> points, double meters) {
    if (points.length < 2) return const [];
    final total = polylineLengthMeters(points);
    if (total <= meters * 2 + 10) return const [];
    var acc = 0.0;
    final keep = <GeoPoint>[];
    for (var i = 0; i < points.length; i++) {
      if (i > 0) acc += distanceMeters(points[i - 1], points[i]);
      if (acc >= meters && acc <= total - meters) keep.add(points[i]);
    }
    return keep.length >= 2 ? keep : const [];
  }

  static double _rad(double deg) => deg * math.pi / 180;
}
