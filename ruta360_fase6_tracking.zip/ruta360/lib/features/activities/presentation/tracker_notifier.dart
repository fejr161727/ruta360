import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/activity_type.dart';
import '../../../core/errors/app_failure.dart';
import '../../../core/utils/geo_utils.dart';
import '../../maps/presentation/location_providers.dart';
import '../domain/track_point.dart';
import '../domain/tracking_engine.dart';

enum TrackerStatus { idle, running, paused, finished }

class TrackerState {
  const TrackerState({
    this.status = TrackerStatus.idle,
    this.type = ActivityType.cycling,
    this.distanceM = 0,
    this.elapsed = Duration.zero,
    this.currentSpeedMps = 0,
    this.maxSpeedMps = 0,
    this.ascentM = 0,
    this.descentM = 0,
    this.points = const [],
    this.lastPoint,
    this.startedAt,
    this.routeId,
    this.error,
  });

  final TrackerStatus status;
  final ActivityType type;
  final double distanceM;
  final Duration elapsed;
  final double currentSpeedMps;
  final double maxSpeedMps;
  final double ascentM;
  final double descentM;
  final List<GeoPoint> points;
  final TrackPoint? lastPoint;
  final DateTime? startedAt;
  final String? routeId;
  final AppFailure? error;

  bool get isActive =>
      status == TrackerStatus.running || status == TrackerStatus.paused;

  double get avgSpeedMps =>
      elapsed.inSeconds > 0 ? distanceM / elapsed.inSeconds : 0;

  /// Estimación aproximada con 70 kg de peso (aún no guardamos el peso).
  double get calories => type.met * 70 * elapsed.inSeconds / 3600;

  TrackerState copyWith({
    TrackerStatus? status,
    double? distanceM,
    Duration? elapsed,
    double? currentSpeedMps,
    double? maxSpeedMps,
    double? ascentM,
    double? descentM,
    List<GeoPoint>? points,
    TrackPoint? lastPoint,
    AppFailure? error,
    bool clearError = false,
  }) {
    return TrackerState(
      status: status ?? this.status,
      type: type,
      distanceM: distanceM ?? this.distanceM,
      elapsed: elapsed ?? this.elapsed,
      currentSpeedMps: currentSpeedMps ?? this.currentSpeedMps,
      maxSpeedMps: maxSpeedMps ?? this.maxSpeedMps,
      ascentM: ascentM ?? this.ascentM,
      descentM: descentM ?? this.descentM,
      points: points ?? this.points,
      lastPoint: lastPoint ?? this.lastPoint,
      startedAt: startedAt,
      routeId: routeId,
      error: clearError ? null : (error ?? this.error),
    );
  }
}

class TrackerNotifier extends Notifier<TrackerState> {
  TrackingEngine _engine = TrackingEngine();
  final Stopwatch _clock = Stopwatch();
  StreamSubscription<TrackPoint>? _sub;
  Timer? _ticker;

  @override
  TrackerState build() {
    ref.onDispose(_stopStreams);
    return const TrackerState();
  }

  Future<void> start(ActivityType type, {String? routeId}) async {
    if (state.isActive) return;
    try {
      await ref.read(locationServiceProvider).ensurePermission();
    } on AppFailure catch (e) {
      state = TrackerState(type: type, error: e);
      return;
    }
    _engine = TrackingEngine();
    _clock
      ..reset()
      ..start();
    state = TrackerState(
      status: TrackerStatus.running,
      type: type,
      startedAt: DateTime.now(),
      routeId: routeId,
    );
    _listen();
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) => _publish());
  }

  void pause() {
    if (state.status != TrackerStatus.running) return;
    _clock.stop();
    _sub?.cancel();
    _sub = null;
    state = state.copyWith(
      status: TrackerStatus.paused,
      elapsed: _clock.elapsed,
      currentSpeedMps: 0,
    );
  }

  void resume() {
    if (state.status != TrackerStatus.paused) return;
    _engine.markGap();
    _clock.start();
    _listen();
    state = state.copyWith(status: TrackerStatus.running);
  }

  void finish() {
    if (!state.isActive) return;
    _clock.stop();
    _stopStreams();
    state = state.copyWith(
      status: TrackerStatus.finished,
      elapsed: _clock.elapsed,
      distanceM: _engine.distanceM,
      maxSpeedMps: _engine.maxSpeedMps,
      ascentM: _engine.ascentM,
      descentM: _engine.descentM,
      currentSpeedMps: 0,
      points: List.of(_engine.points),
    );
  }

  void reset() {
    _stopStreams();
    _clock
      ..stop()
      ..reset();
    state = const TrackerState();
  }

  void clearError() => state = state.copyWith(clearError: true);

  void _listen() {
    _sub?.cancel();
    _sub = ref.read(locationServiceProvider).positionStream().listen(
      _onPoint,
      onError: (Object e) {
        state = state.copyWith(
          error: e is AppFailure
              ? e
              : const AppFailure('Se perdió la señal del GPS.'),
        );
      },
    );
  }

  void _onPoint(TrackPoint p) {
    if (state.status != TrackerStatus.running) return;
    final accepted = _engine.add(p);
    _publish(pointsChanged: accepted, last: p);
  }

  void _publish({bool pointsChanged = false, TrackPoint? last}) {
    if (state.status != TrackerStatus.running) return;
    state = state.copyWith(
      elapsed: _clock.elapsed,
      distanceM: _engine.distanceM,
      currentSpeedMps: _engine.currentSpeedMps,
      maxSpeedMps: _engine.maxSpeedMps,
      ascentM: _engine.ascentM,
      descentM: _engine.descentM,
      points: pointsChanged ? List.of(_engine.points) : null,
      lastPoint: last,
    );
  }

  void _stopStreams() {
    _sub?.cancel();
    _sub = null;
    _ticker?.cancel();
    _ticker = null;
  }
}

final trackerProvider =
    NotifierProvider<TrackerNotifier, TrackerState>(TrackerNotifier.new);
