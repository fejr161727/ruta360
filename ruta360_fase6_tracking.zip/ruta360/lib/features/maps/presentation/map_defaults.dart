import '../../../core/utils/geo_utils.dart';

/// Centro inicial provisional (Quito) mientras no hay ubicación del usuario.
const kDefaultMapCenter = GeoPoint(-0.1807, -78.4678);
