import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/errors/app_failure.dart';
import '../../../core/utils/geo_utils.dart';
import '../../maps/domain/location_service.dart';
import '../../maps/presentation/location_providers.dart';
import '../../maps/presentation/widgets/ruta_map_view.dart';

/// Centro inicial provisional (Quito) mientras no hay ubicación del usuario.
const _defaultCenter = GeoPoint(-0.1807, -78.4678);

class ExploreScreen extends ConsumerStatefulWidget {
  const ExploreScreen({super.key});

  @override
  ConsumerState<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends ConsumerState<ExploreScreen> {
  final _map = RutaMapController();
  GeoPoint? _position;
  AppFailure? _failure;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _locate());
  }

  @override
  void dispose() {
    _map.dispose();
    super.dispose();
  }

  Future<void> _locate() async {
    if (_loading) return;
    setState(() {
      _loading = true;
      _failure = null;
    });
    try {
      final p = await ref.read(locationServiceProvider).currentPosition();
      if (!mounted) return;
      setState(() => _position = p);
      _map.moveTo(p, zoom: 15);
    } on AppFailure catch (e) {
      if (mounted) setState(() => _failure = e);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final failure = _failure;
    return Scaffold(
      appBar: AppBar(title: const Text('Explorar')),
      floatingActionButton: FloatingActionButton(
        tooltip: 'Mi ubicación',
        onPressed: _loading ? null : _locate,
        child: _loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            : const Icon(Icons.my_location),
      ),
      body: Stack(
        children: [
          RutaMapView(
            controller: _map,
            center: _position ?? _defaultCenter,
            zoom: _position == null ? 12 : 15,
            userLocation: _position,
          ),
          if (failure != null)
            Positioned(
              left: 12,
              right: 12,
              top: 12,
              child: _LocationBanner(
                failure: failure,
                onRetry: _locate,
                onOpenSettings: failure is LocationFailure &&
                        (failure.issue == LocationIssue.serviceDisabled ||
                            failure.issue == LocationIssue.deniedForever)
                    ? () => ref
                        .read(locationServiceProvider)
                        .openSettings(failure.issue)
                    : null,
              ),
            ),
        ],
      ),
    );
  }
}

class _LocationBanner extends StatelessWidget {
  const _LocationBanner({
    required this.failure,
    required this.onRetry,
    this.onOpenSettings,
  });

  final AppFailure failure;
  final VoidCallback onRetry;
  final VoidCallback? onOpenSettings;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.location_off_outlined),
                const SizedBox(width: 8),
                Expanded(child: Text(failure.message)),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                if (onOpenSettings != null)
                  TextButton(
                    onPressed: onOpenSettings,
                    child: const Text('Abrir ajustes'),
                  ),
                TextButton(onPressed: onRetry, child: const Text('Reintentar')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
