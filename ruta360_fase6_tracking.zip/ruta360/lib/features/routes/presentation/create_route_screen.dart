import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/utils/formatters.dart';
import '../../../core/utils/geo_utils.dart';
import '../../maps/presentation/location_providers.dart';
import '../../maps/presentation/map_defaults.dart';
import '../../maps/presentation/widgets/ruta_map_view.dart';
import 'widgets/route_form_sheet.dart';

class CreateRouteScreen extends ConsumerStatefulWidget {
  const CreateRouteScreen({super.key});

  @override
  ConsumerState<CreateRouteScreen> createState() => _CreateRouteScreenState();
}

class _CreateRouteScreenState extends ConsumerState<CreateRouteScreen> {
  final _map = RutaMapController();
  final List<GeoPoint> _points = [];
  GeoPoint? _user;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _centerOnUser());
  }

  @override
  void dispose() {
    _map.dispose();
    super.dispose();
  }

  Future<void> _centerOnUser() async {
    try {
      final p = await ref.read(locationServiceProvider).currentPosition();
      if (!mounted) return;
      setState(() => _user = p);
      if (_points.isEmpty) _map.moveTo(p, zoom: 15);
    } catch (_) {
      // Sin ubicación: se puede dibujar igualmente sobre el mapa.
    }
  }

  double get _distance => GeoUtils.polylineLengthMeters(_points);

  void _add(GeoPoint p) => setState(() => _points.add(p));

  void _removeAt(int i) => setState(() => _points.removeAt(i));

  void _undo() {
    if (_points.isNotEmpty) setState(() => _points.removeLast());
  }

  Future<void> _clear() async {
    if (_points.isEmpty) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Borrar todos los puntos'),
        content: const Text('Se perderá el trazado actual.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar')),
          FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Borrar')),
        ],
      ),
    );
    if (ok == true) setState(_points.clear);
  }

  Future<void> _next() async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => RouteFormSheet(
        points: List.of(_points),
        distanceMeters: _distance,
      ),
    );
    if (saved == true && mounted) context.pop();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final last = _points.length - 1;
    return Scaffold(
      appBar: AppBar(title: const Text('Nueva ruta')),
      body: Stack(
        children: [
          RutaMapView(
            controller: _map,
            center: _user ?? kDefaultMapCenter,
            zoom: _user == null ? 12 : 15,
            userLocation: _user,
            onTap: _add,
            polylines: [MapPolylineData(points: _points)],
            markers: [
              for (var i = 0; i < _points.length; i++)
                MapMarkerData(
                  point: _points[i],
                  icon: Icons.circle,
                  size: 22,
                  centered: true,
                  color: i == 0
                      ? Colors.green
                      : (i == last ? Colors.red : scheme.primary),
                  onTap: () => _removeAt(i),
                ),
            ],
          ),
          if (_points.isEmpty)
            const Positioned(
              left: 16,
              right: 16,
              top: 12,
              child: Card(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text(
                    'Toca el mapa para agregar puntos. Toca un punto para quitarlo.',
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          Positioned(
            left: 12,
            right: 12,
            bottom: 12,
            child: Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${Fmt.km(_distance)} km · ${_points.length} puntos',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        IconButton(
                          tooltip: 'Deshacer',
                          onPressed: _points.isEmpty ? null : _undo,
                          icon: const Icon(Icons.undo),
                        ),
                        IconButton(
                          tooltip: 'Borrar todo',
                          onPressed: _points.isEmpty ? null : _clear,
                          icon: const Icon(Icons.delete_sweep_outlined),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: FilledButton(
                            onPressed: _points.length < 2 ? null : _next,
                            child: const Text('Siguiente'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
