import 'package:flutter/material.dart';

/// Paleta de RUTA360: azul de marca sobre fondo blanco.
class AppColors {
  const AppColors._();
  static const Color primary = Color(0xFF1565C0);
  static const Color accent = Color(0xFFFF6B2C);
  static const Color darkSurface = Color(0xFF0F1419);
}
