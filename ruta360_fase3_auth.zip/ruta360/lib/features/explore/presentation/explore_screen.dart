import 'package:flutter/material.dart';
import '../../../shared/widgets/empty_state.dart';

class ExploreScreen extends StatelessWidget {
  const ExploreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Explorar')),
      body: const EmptyState(
        icon: Icons.map_outlined,
        title: 'Explorar',
        message: 'El mapa y los filtros de rutas llegan en las Fases 4-5.',
      ),
    );
  }
}
