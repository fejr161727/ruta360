import 'package:flutter_test/flutter_test.dart';
import 'package:ruta360/core/utils/formatters.dart';

void main() {
  test('duración', () {
    expect(Fmt.duration(const Duration(seconds: 65)), '01:05');
    expect(Fmt.duration(const Duration(seconds: 3725)), '1:02:05');
  });
  test('distancia y minutos', () {
    expect(Fmt.km(12340), '12.34');
    expect(Fmt.minutes(45), '45 min');
    expect(Fmt.minutes(125), '2 h 5 min');
    expect(Fmt.minutes(120), '2 h');
  });
}
