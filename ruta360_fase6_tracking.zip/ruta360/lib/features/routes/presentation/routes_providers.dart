import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../auth/presentation/auth_providers.dart';
import '../data/firestore_route_repository.dart';
import '../domain/route_model.dart';
import '../domain/route_repository.dart';

final routeRepositoryProvider = Provider<RouteRepository>(
  (ref) => FirestoreRouteRepository(),
);

/// Rutas públicas + las propias (incluye privadas), sin duplicados.
final exploreRoutesProvider = FutureProvider<List<RouteModel>>((ref) async {
  final repo = ref.watch(routeRepositoryProvider);
  final uid = ref.watch(authStateProvider.select((a) => a.valueOrNull?.uid));
  final results = await Future.wait([
    repo.publicRoutes(),
    if (uid != null) repo.myRoutes(uid),
  ]);
  final byId = <String, RouteModel>{
    for (final list in results)
      for (final r in list) r.id: r,
  };
  return byId.values.toList();
});

final routeByIdProvider =
    FutureProvider.autoDispose.family<RouteModel?, String>((ref, id) {
  return ref.watch(routeRepositoryProvider).byId(id);
});

/// Ruta elegida para seguir mientras se registra una actividad.
final guidedRouteProvider = StateProvider<RouteModel?>((ref) => null);
