"""Configura Android para RUTA360 tras `flutter create`.
- Copia google-services.json a android/app
- Fija applicationId = ec.ruta360.app (debe coincidir con Firebase)
- Añade el plugin de Google Services y el permiso INTERNET
"""
import pathlib
import re
import shutil
import sys

PKG = "ec.ruta360.app"
GS_PLUGIN_VERSION = "4.4.2"

root = pathlib.Path(".")
gs = root / "google-services.json"
if not gs.exists():
    sys.exit("ERROR: falta google-services.json en la raiz del repositorio")
if PKG not in gs.read_text(encoding="utf-8"):
    sys.exit(f"ERROR: google-services.json no corresponde al paquete {PKG}")
shutil.copy(gs, root / "android/app/google-services.json")

# settings.gradle.kts: declarar el plugin
settings = root / "android/settings.gradle.kts"
if not settings.exists():
    sys.exit("ERROR: no se encontro android/settings.gradle.kts (version de Flutter distinta)")
s = settings.read_text(encoding="utf-8")
if "com.google.gms.google-services" not in s:
    s, n = re.subn(
        r'(\n\s*id\("com\.android\.application"\) version [^\n]*)',
        r'\1\n    id("com.google.gms.google-services") version "%s" apply false' % GS_PLUGIN_VERSION,
        s, count=1)
    if n == 0:
        sys.exit("ERROR: no se pudo anadir el plugin en settings.gradle.kts")
    settings.write_text(s, encoding="utf-8")

# app/build.gradle.kts: aplicar plugin, applicationId y minSdk
app = root / "android/app/build.gradle.kts"
if not app.exists():
    sys.exit("ERROR: no se encontro android/app/build.gradle.kts")
a = app.read_text(encoding="utf-8")
if "com.google.gms.google-services" not in a:
    a, n = re.subn(
        r'(\n\s*id\("com\.android\.application"\)[^\n]*)',
        r'\1\n    id("com.google.gms.google-services")',
        a, count=1)
    if n == 0:
        sys.exit("ERROR: no se pudo aplicar el plugin en app/build.gradle.kts")
a, n = re.subn(r'applicationId\s*=\s*"[^"]+"', 'applicationId = "%s"' % PKG, a, count=1)
if n == 0:
    sys.exit("ERROR: no se encontro applicationId")
a = re.sub(r'minSdk\s*=\s*flutter\.minSdkVersion', 'minSdk = 24', a)
app.write_text(a, encoding="utf-8")

# Permisos: INTERNET y ubicacion (primer plano)
manifest = root / "android/app/src/main/AndroidManifest.xml"
m = manifest.read_text(encoding="utf-8")
for perm in (
    "android.permission.INTERNET",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.ACCESS_COARSE_LOCATION",
):
    if perm not in m:
        m = m.replace(
            "<application",
            '<uses-permission android:name="%s"/>\n    <application' % perm,
            1,
        )
manifest.write_text(m, encoding="utf-8")

print("Android configurado para", PKG)
