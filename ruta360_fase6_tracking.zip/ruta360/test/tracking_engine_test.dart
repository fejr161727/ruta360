import 'package:flutter_test/flutter_test.dart';
import 'package:ruta360/features/activities/domain/track_point.dart';
import 'package:ruta360/features/activities/domain/tracking_engine.dart';

final t0 = DateTime(2026, 1, 1, 8);

/// 0.0001° de latitud ≈ 11.1 m.
TrackPoint pt(int i,
    {double stepDeg = 0.0001,
    int secondsEach = 5,
    double? alt,
    double? accuracy,
    double? speed}) {
  return TrackPoint(
    lat: -0.18 + i * stepDeg,
    lng: -78.47,
    time: t0.add(Duration(seconds: i * secondsEach)),
    altitude: alt,
    accuracy: accuracy,
    speedMps: speed,
  );
}

void main() {
  test('acumula distancia y velocidad máxima', () {
    final e = TrackingEngine();
    for (var i = 0; i < 11; i++) {
      expect(e.add(pt(i)), isTrue);
    }
    expect(e.distanceM, closeTo(111, 3));
    expect(e.maxSpeedMps, closeTo(2.2, 0.1));
    expect(e.points.length, 11);
  });

  test('descarta puntos con mala precisión', () {
    final e = TrackingEngine();
    e.add(pt(0));
    expect(e.add(pt(1, accuracy: 80)), isFalse);
    expect(e.points.length, 1);
  });

  test('ignora el ruido cuando está quieto', () {
    final e = TrackingEngine();
    e.add(pt(0));
    // ~1 m de desplazamiento: por debajo del paso mínimo
    expect(e.add(pt(1, stepDeg: 0.000009)), isFalse);
    expect(e.distanceM, 0);
  });

  test('descarta saltos de GPS irreales', () {
    final e = TrackingEngine();
    e.add(pt(0));
    // 1 grado en 5 segundos
    expect(e.add(pt(1, stepDeg: 1.0)), isFalse);
    expect(e.distanceM, 0);
  });

  test('tras una pausa no suma la distancia recorrida sin registrar', () {
    final e = TrackingEngine();
    e.add(pt(0));
    e.add(pt(1));
    final before = e.distanceM;
    e.markGap();
    // reanuda 1 km más lejos
    expect(e.add(pt(100, secondsEach: 5)), isTrue);
    expect(e.distanceM, closeTo(before, 0.001));
  });

  test('desnivel con umbral: ignora ruido pequeño', () {
    final e = TrackingEngine();
    e.add(pt(0, alt: 2800));
    e.add(pt(1, alt: 2801.5)); // ruido
    e.add(pt(2, alt: 2806)); // +6 respecto a la referencia
    e.add(pt(3, alt: 2800)); // -6
    expect(e.ascentM, closeTo(6, 0.01));
    expect(e.descentM, closeTo(6, 0.01));
  });
}
