import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/activities/presentation/activities_screen.dart';
import '../../features/auth/presentation/auth_providers.dart';
import '../../features/auth/presentation/forgot_password_screen.dart';
import '../../features/auth/presentation/login_screen.dart';
import '../../features/auth/presentation/register_screen.dart';
import '../../features/communities/presentation/communities_screen.dart';
import '../../features/explore/presentation/explore_screen.dart';
import '../../features/home/presentation/home_screen.dart';
import '../../features/profile/presentation/profile_screen.dart';
import '../../features/routes/presentation/create_route_screen.dart';
import '../../features/routes/presentation/my_routes_screen.dart';
import '../../features/routes/presentation/route_detail_screen.dart';
import '../../shared/widgets/main_shell.dart';
import '../../shared/widgets/splash_screen.dart';

abstract class AppRoutes {
  static const splash = '/splash';
  static const login = '/login';
  static const register = '/register';
  static const forgot = '/forgot';
  static const home = '/home';
  static const explore = '/explore';
  static const record = '/record';
  static const communities = '/communities';
  static const profile = '/profile';
  static const routeNew = '/routes/new';
  static const myRoutes = '/routes/mine';
  static String routeDetail(String id) => '/routes/$id';

  static const publicRoutes = {login, register, forgot};
}

final appRouterProvider = Provider<GoRouter>((ref) {
  final refresh = ValueNotifier<int>(0);
  ref.listen(authStateProvider, (_, __) => refresh.value++);
  ref.onDispose(refresh.dispose);

  return GoRouter(
    initialLocation: AppRoutes.splash,
    refreshListenable: refresh,
    redirect: (context, state) {
      final auth = ref.read(authStateProvider);
      final loc = state.matchedLocation;

      if (auth.isLoading) {
        return loc == AppRoutes.splash ? null : AppRoutes.splash;
      }
      final loggedIn = auth.valueOrNull != null;
      final isPublic = AppRoutes.publicRoutes.contains(loc);

      if (!loggedIn) return isPublic ? null : AppRoutes.login;
      if (isPublic || loc == AppRoutes.splash) return AppRoutes.home;
      return null;
    },
    routes: [
      GoRoute(path: AppRoutes.splash, builder: (_, __) => const SplashScreen()),
      GoRoute(path: AppRoutes.login, builder: (_, __) => const LoginScreen()),
      GoRoute(
          path: AppRoutes.register, builder: (_, __) => const RegisterScreen()),
      GoRoute(
          path: AppRoutes.forgot,
          builder: (_, __) => const ForgotPasswordScreen()),
      GoRoute(
          path: AppRoutes.routeNew,
          builder: (_, __) => const CreateRouteScreen()),
      GoRoute(
          path: AppRoutes.myRoutes,
          builder: (_, __) => const MyRoutesScreen()),
      GoRoute(
        path: '/routes/:id',
        builder: (_, state) =>
            RouteDetailScreen(routeId: state.pathParameters['id']!),
      ),
      StatefulShellRoute.indexedStack(
        builder: (context, state, shell) => MainShell(navigationShell: shell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(path: AppRoutes.home, builder: (_, __) => const HomeScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
                path: AppRoutes.explore,
                builder: (_, __) => const ExploreScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
                path: AppRoutes.record,
                builder: (_, __) => const ActivitiesScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
                path: AppRoutes.communities,
                builder: (_, __) => const CommunitiesScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
                path: AppRoutes.profile,
                builder: (_, __) => const ProfileScreen()),
          ]),
        ],
      ),
    ],
  );
});
