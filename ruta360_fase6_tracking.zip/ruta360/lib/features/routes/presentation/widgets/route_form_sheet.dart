import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/activity_type.dart';
import '../../../../core/constants/route_enums.dart';
import '../../../../core/errors/app_failure.dart';
import '../../../../core/utils/formatters.dart';
import '../../../../core/utils/geo_utils.dart';
import '../../../auth/presentation/auth_providers.dart';
import '../../domain/route_model.dart';
import '../routes_providers.dart';

class RouteFormSheet extends ConsumerStatefulWidget {
  const RouteFormSheet({
    super.key,
    required this.points,
    required this.distanceMeters,
  });

  final List<GeoPoint> points;
  final double distanceMeters;

  @override
  ConsumerState<RouteFormSheet> createState() => _RouteFormSheetState();
}

class _RouteFormSheetState extends ConsumerState<RouteFormSheet> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _description = TextEditingController();
  ActivityType _activity = ActivityType.cycling;
  Difficulty _difficulty = Difficulty.moderate;
  Surface _surface = Surface.mixed;
  ContentVisibility _visibility = ContentVisibility.public;
  bool _saving = false;

  @override
  void dispose() {
    _name.dispose();
    _description.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final user = ref.read(authStateProvider).valueOrNull;
    if (user == null) return;
    final messenger = ScaffoldMessenger.of(context);
    setState(() => _saving = true);
    try {
      final ownerName = (user.displayName?.trim().isNotEmpty ?? false)
          ? user.displayName!.trim()
          : user.email.split('@').first;
      final route = RouteModel(
        id: '',
        ownerId: user.uid,
        ownerName: ownerName,
        name: _name.text,
        description: _description.text,
        activity: _activity,
        difficulty: _difficulty,
        surface: _surface,
        distanceMeters: widget.distanceMeters,
        ascentMeters: 0,
        points: widget.points,
        visibility: _visibility,
      );
      var queued = false;
      try {
        await ref
            .read(routeRepositoryProvider)
            .create(route)
            .timeout(const Duration(seconds: 12));
      } on TimeoutException {
        // Sin conexión: Firestore la guarda en el dispositivo y la sube después.
        queued = true;
      }
      ref.invalidate(exploreRoutesProvider);
      messenger.showSnackBar(SnackBar(
        content: Text(queued
            ? 'Sin conexión: la ruta se enviará cuando vuelva internet.'
            : 'Ruta guardada.'),
      ));
      if (mounted) Navigator.of(context).pop(true);
    } on AppFailure catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        8,
        20,
        20 + MediaQuery.of(context).viewInsets.bottom,
      ),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Guardar ruta', style: text.titleLarge),
              const SizedBox(height: 4),
              Text('${Fmt.km(widget.distanceMeters)} km · '
                  '${widget.points.length} puntos'),
              const SizedBox(height: 16),
              TextFormField(
                controller: _name,
                textCapitalization: TextCapitalization.sentences,
                maxLength: 80,
                decoration: const InputDecoration(labelText: 'Nombre'),
                validator: (v) => (v == null || v.trim().length < 3)
                    ? 'Escribe un nombre (mínimo 3 letras)'
                    : null,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _description,
                maxLines: 3,
                maxLength: 500,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(
                    labelText: 'Descripción (opcional)',
                    alignLabelWithHint: true),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<ActivityType>(
                value: _activity,
                decoration: const InputDecoration(labelText: 'Actividad'),
                items: [
                  for (final a in ActivityType.values)
                    DropdownMenuItem(value: a, child: Text(a.label)),
                ],
                onChanged: (v) => setState(() => _activity = v ?? _activity),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<Difficulty>(
                value: _difficulty,
                decoration: const InputDecoration(labelText: 'Dificultad'),
                items: [
                  for (final d in Difficulty.values)
                    DropdownMenuItem(value: d, child: Text(d.label)),
                ],
                onChanged: (v) =>
                    setState(() => _difficulty = v ?? _difficulty),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<Surface>(
                value: _surface,
                decoration: const InputDecoration(labelText: 'Superficie'),
                items: [
                  for (final s in Surface.values)
                    DropdownMenuItem(value: s, child: Text(s.label)),
                ],
                onChanged: (v) => setState(() => _surface = v ?? _surface),
              ),
              const SizedBox(height: 16),
              SegmentedButton<ContentVisibility>(
                segments: const [
                  ButtonSegment(
                      value: ContentVisibility.public,
                      icon: Icon(Icons.public),
                      label: Text('Pública')),
                  ButtonSegment(
                      value: ContentVisibility.private,
                      icon: Icon(Icons.lock_outline),
                      label: Text('Privada')),
                ],
                selected: {_visibility},
                onSelectionChanged: (s) =>
                    setState(() => _visibility = s.first),
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: _saving ? null : _save,
                child: _saving
                    ? const SizedBox(
                        height: 22,
                        width: 22,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text('Guardar ruta'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
