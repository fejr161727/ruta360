import 'geo_utils.dart';

/// Codificación "encoded polyline" (precisión 5) para guardar recorridos
/// en un solo campo de texto de Firestore.
class PolylineCodec {
  const PolylineCodec._();

  static String encode(List<GeoPoint> points) {
    final sb = StringBuffer();
    var prevLat = 0;
    var prevLng = 0;
    for (final p in points) {
      final lat = (p.lat * 1e5).round();
      final lng = (p.lng * 1e5).round();
      _write(lat - prevLat, sb);
      _write(lng - prevLng, sb);
      prevLat = lat;
      prevLng = lng;
    }
    return sb.toString();
  }

  static List<GeoPoint> decode(String encoded) {
    final points = <GeoPoint>[];
    var index = 0;
    var lat = 0;
    var lng = 0;
    while (index < encoded.length) {
      var shift = 0;
      var result = 0;
      var b = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20 && index < encoded.length);
      lat += (result & 1) != 0 ? ~(result >> 1) : (result >> 1);

      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20 && index < encoded.length);
      lng += (result & 1) != 0 ? ~(result >> 1) : (result >> 1);

      points.add(GeoPoint(lat / 1e5, lng / 1e5));
    }
    return points;
  }

  static void _write(int value, StringBuffer sb) {
    var v = value < 0 ? ~(value << 1) : (value << 1);
    while (v >= 0x20) {
      sb.writeCharCode((0x20 | (v & 0x1f)) + 63);
      v >>= 5;
    }
    sb.writeCharCode(v + 63);
  }
}
