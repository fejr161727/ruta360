import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/errors/app_failure.dart';
import '../../../core/router/app_router.dart';
import '../../../core/utils/formatters.dart';
import '../../../shared/widgets/async_error_view.dart';
import '../../../shared/widgets/empty_state.dart';
import '../../../shared/widgets/stat_tile.dart';
import '../../auth/presentation/auth_providers.dart';
import '../../maps/presentation/widgets/ruta_map_view.dart';
import '../domain/route_model.dart';
import 'routes_providers.dart';

class RouteDetailScreen extends ConsumerWidget {
  const RouteDetailScreen({super.key, required this.routeId});

  final String routeId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(routeByIdProvider(routeId));
    return Scaffold(
      appBar: AppBar(title: const Text('Ruta')),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => AsyncErrorView(
          error: e,
          onRetry: () => ref.invalidate(routeByIdProvider(routeId)),
        ),
        data: (route) => route == null
            ? const EmptyState(
                icon: Icons.search_off,
                title: 'Ruta no encontrada',
                message: 'Puede que haya sido eliminada.',
              )
            : _RouteDetailBody(route: route),
      ),
    );
  }
}

class _RouteDetailBody extends ConsumerStatefulWidget {
  const _RouteDetailBody({required this.route});

  final RouteModel route;

  @override
  ConsumerState<_RouteDetailBody> createState() => _RouteDetailBodyState();
}

class _RouteDetailBodyState extends ConsumerState<_RouteDetailBody> {
  final _map = RutaMapController();
  bool _deleting = false;

  @override
  void initState() {
    super.initState();
    _map.fitTo(widget.route.points, padding: 40);
  }

  @override
  void dispose() {
    _map.dispose();
    super.dispose();
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Eliminar ruta'),
        content: const Text('Esta acción no se puede deshacer.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar')),
          FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Eliminar')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _deleting = true);
    try {
      await ref.read(routeRepositoryProvider).delete(widget.route.id);
      ref.invalidate(exploreRoutesProvider);
      if (mounted) context.pop();
    } on AppFailure catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.message)));
      }
    } finally {
      if (mounted) setState(() => _deleting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.route;
    final text = Theme.of(context).textTheme;
    final uid = ref.watch(authStateProvider).valueOrNull?.uid;
    final isOwner = uid != null && uid == r.ownerId;

    return ListView(
      children: [
        SizedBox(
          height: 280,
          child: RutaMapView(
            controller: _map,
            center: r.start,
            zoom: 13,
            polylines: [MapPolylineData(points: r.points)],
            markers: [
              MapMarkerData(
                  point: r.start,
                  icon: Icons.trip_origin,
                  color: Colors.green,
                  size: 26,
                  centered: true),
              MapMarkerData(
                  point: r.end, icon: Icons.location_on, color: Colors.red),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(r.name, style: text.headlineSmall),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  Chip(
                      avatar: Icon(r.activity.icon, size: 18),
                      label: Text(r.activity.label)),
                  Chip(label: Text(r.difficulty.label)),
                  Chip(label: Text(r.surface.label)),
                  if (!r.isPublic)
                    const Chip(
                        avatar: Icon(Icons.lock_outline, size: 18),
                        label: Text('Privada')),
                ],
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 24,
                runSpacing: 16,
                children: [
                  StatTile(
                      label: 'Distancia',
                      value: Fmt.km(r.distanceMeters),
                      unit: 'km'),
                  StatTile(
                      label: 'Tiempo estimado',
                      value: Fmt.minutes(r.estimatedMinutes)),
                  if (r.ascentMeters > 0)
                    StatTile(
                        label: 'Desnivel +',
                        value: Fmt.meters(r.ascentMeters),
                        unit: 'm'),
                ],
              ),
              const SizedBox(height: 16),
              if (r.description.trim().isNotEmpty) ...[
                Text(r.description),
                const SizedBox(height: 16),
              ],
              Text(
                'Por ${r.ownerName}'
                '${r.createdAt == null ? '' : ' · ${Fmt.date(r.createdAt!)}'}',
                style: text.bodySmall,
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: () {
                  ref.read(guidedRouteProvider.notifier).state = r;
                  context.go(AppRoutes.record);
                },
                icon: const Icon(Icons.play_arrow),
                label: const Text('Seguir esta ruta'),
              ),
              const SizedBox(height: 12),
              if (isOwner)
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _deleting ? null : _delete,
                        icon: const Icon(Icons.delete_outline),
                        label: const Text('Eliminar ruta'),
                      ),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ],
    );
  }
}
