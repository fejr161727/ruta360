import 'package:flutter/material.dart';

import '../../../../core/constants/activity_type.dart';
import '../../../../core/utils/formatters.dart';
import '../../../../shared/widgets/stat_tile.dart';

class ActivityStats extends StatelessWidget {
  const ActivityStats({
    super.key,
    required this.type,
    required this.distanceM,
    required this.elapsed,
    required this.avgSpeedMps,
    required this.maxSpeedMps,
    required this.ascentM,
    required this.calories,
    this.currentSpeedMps,
    this.showTime = true,
  });

  final ActivityType type;
  final double distanceM;
  final Duration elapsed;
  final double avgSpeedMps;
  final double maxSpeedMps;
  final double ascentM;
  final double calories;
  final double? currentSpeedMps;
  final bool showTime;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        StatTile(label: 'Distancia', value: Fmt.km(distanceM), unit: 'km'),
        if (showTime) StatTile(label: 'Tiempo', value: Fmt.duration(elapsed)),
        if (currentSpeedMps != null)
          StatTile(
              label: 'Vel. actual',
              value: Fmt.kmh(currentSpeedMps! * 3.6),
              unit: 'km/h'),
        StatTile(
            label: 'Vel. promedio',
            value: Fmt.kmh(avgSpeedMps * 3.6),
            unit: 'km/h'),
        StatTile(
            label: 'Vel. máxima',
            value: Fmt.kmh(maxSpeedMps * 3.6),
            unit: 'km/h'),
        if (type.usesPace)
          StatTile(label: 'Ritmo', value: Fmt.pace(avgSpeedMps), unit: 'min/km'),
        StatTile(label: 'Desnivel +', value: Fmt.meters(ascentM), unit: 'm'),
        if (type != ActivityType.moto)
          StatTile(
              label: 'Calorías ≈',
              value: calories.round().toString(),
              unit: 'kcal'),
      ],
    );
  }
}
