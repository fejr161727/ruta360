import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/constants/activity_type.dart';
import '../../../core/router/app_router.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/geo_utils.dart';
import '../../../shared/widgets/async_error_view.dart';
import '../../../shared/widgets/ruta_logo.dart';
import '../../../shared/widgets/stat_tile.dart';
import '../../activities/domain/activity_model.dart';
import '../../activities/presentation/activity_providers.dart';
import '../../auth/presentation/auth_providers.dart';
import '../../maps/presentation/location_providers.dart';
import '../../routes/domain/route_filters.dart';
import '../../routes/domain/route_model.dart';
import '../../routes/presentation/route_filters_provider.dart';
import '../../routes/presentation/routes_providers.dart';

/// Posición del usuario para ordenar rutas cercanas (null si no hay permiso/GPS).
final homePositionProvider = FutureProvider.autoDispose<GeoPoint?>((ref) async {
  try {
    return await ref.read(locationServiceProvider).currentPosition();
  } catch (_) {
    return null;
  }
});

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  Future<void> _refresh(WidgetRef ref) async {
    ref.invalidate(exploreRoutesProvider);
    ref.invalidate(myActivitiesProvider);
    try {
      await ref.read(exploreRoutesProvider.future);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateProvider).valueOrNull;
    final text = Theme.of(context).textTheme;
    final scheme = Theme.of(context).colorScheme;

    final fullName = (user?.displayName?.trim().isNotEmpty ?? false)
        ? user!.displayName!.trim()
        : (user?.email.split('@').first ?? 'deportista');
    final firstName = fullName.split(' ').first;

    final routesAsync = ref.watch(exploreRoutesProvider);
    final actsAsync = ref.watch(myActivitiesProvider);
    final pos = ref.watch(homePositionProvider).valueOrNull;

    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            RutaLogo(size: 28),
            SizedBox(width: 8),
            Text('RUTA360'),
          ],
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () => _refresh(ref),
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => context.go(AppRoutes.profile),
                    child: CircleAvatar(
                      radius: 22,
                      backgroundColor: scheme.primary.withOpacity(0.14),
                      child: Text(user?.initial ?? '?',
                          style: text.titleMedium
                              ?.copyWith(color: scheme.primary)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Hola, $firstName', style: text.titleLarge),
                        Text('¿Qué ruta hacemos hoy?', style: text.bodySmall),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                readOnly: true,
                onTap: () => context.go(AppRoutes.explore),
                decoration: const InputDecoration(
                  hintText: 'Buscar rutas',
                  prefixIcon: Icon(Icons.search),
                  isDense: true,
                ),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 44,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: ActivityType.values.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, i) {
                  final a = ActivityType.values[i];
                  return ActionChip(
                    avatar: Icon(a.icon, size: 18),
                    label: Text(a.label),
                    onPressed: () {
                      ref
                          .read(routeFiltersProvider.notifier)
                          .update((f) => f.copyWith(activity: () => a));
                      context.go(AppRoutes.explore);
                    },
                  );
                },
              ),
            ),
            ..._summary(context, actsAsync),
            _sectionTitle(
              context,
              pos == null ? 'Rutas recientes' : 'Rutas cerca de ti',
              actionLabel: 'Ver todas',
              onAction: () => context.go(AppRoutes.explore),
            ),
            routesAsync.when(
              loading: () => const SizedBox(
                  height: 120,
                  child: Center(child: CircularProgressIndicator())),
              error: (e, _) => SizedBox(
                height: 200,
                child: AsyncErrorView(
                  error: e,
                  onRetry: () => ref.invalidate(exploreRoutesProvider),
                ),
              ),
              data: (all) => _routesRow(context, all, pos),
            ),
            _sectionTitle(
              context,
              'Tus últimas actividades',
              actionLabel: 'Ver todas',
              onAction: () => context.push(AppRoutes.myActivities),
            ),
            actsAsync.when(
              loading: () => const SizedBox(
                  height: 80,
                  child: Center(child: CircularProgressIndicator())),
              error: (e, _) => SizedBox(
                height: 200,
                child: AsyncErrorView(
                  error: e,
                  onRetry: () => ref.invalidate(myActivitiesProvider),
                ),
              ),
              data: (acts) {
                if (acts.isEmpty) {
                  return _emptyCard(
                    context,
                    icon: Icons.directions_run,
                    message: 'Aún no has registrado actividades.',
                    buttonLabel: 'Registrar la primera',
                    onPressed: () => context.go(AppRoutes.record),
                  );
                }
                return Column(
                  children: [
                    for (final a in acts.take(3))
                      Card(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 4),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: scheme.primary.withOpacity(0.12),
                            child: Icon(a.type.icon, color: scheme.primary),
                          ),
                          title: Text(a.title,
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text(
                            '${Fmt.km(a.distanceMeters)} km · '
                            '${Fmt.duration(Duration(seconds: a.movingSeconds))} · '
                            '${Fmt.date(a.startedAt)}',
                          ),
                          onTap: () =>
                              context.push(AppRoutes.activityDetail(a.id)),
                        ),
                      ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _summary(BuildContext context, AsyncValue<List<ActivityModel>> acts) {
    final list = acts.valueOrNull;
    if (list == null || list.isEmpty) return const [];
    final totalM = list.fold<double>(0, (s, a) => s + a.distanceMeters);
    final totalS = list.fold<int>(0, (s, a) => s + a.movingSeconds);
    return [
      _sectionTitle(context, 'Tu resumen'),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            StatTile(label: 'Actividades', value: '${list.length}'),
            StatTile(label: 'Distancia', value: Fmt.km(totalM), unit: 'km'),
            StatTile(
                label: 'Tiempo', value: Fmt.duration(Duration(seconds: totalS))),
          ],
        ),
      ),
    ];
  }

  Widget _routesRow(BuildContext context, List<RouteModel> all, GeoPoint? pos) {
    if (all.isEmpty) {
      return _emptyCard(
        context,
        icon: Icons.route_outlined,
        message: 'Aún no hay rutas. Crea la primera.',
        buttonLabel: 'Crear ruta',
        onPressed: () => context.push(AppRoutes.routeNew),
      );
    }
    final sorted = applyRouteFilters(
      all,
      RouteFilters(sort: pos == null ? RouteSort.newest : RouteSort.nearest),
      userPosition: pos,
    ).take(6).toList();
    final scheme = Theme.of(context).colorScheme;
    final text = Theme.of(context).textTheme;
    return SizedBox(
      height: 132,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: sorted.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) {
          final r = sorted[i];
          final near = pos == null
              ? ''
              : ' · a ${Fmt.km(GeoUtils.distanceMeters(pos, r.start))} km';
          return SizedBox(
            width: 230,
            child: Card(
              margin: EdgeInsets.zero,
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => context.push(AppRoutes.routeDetail(r.id)),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(r.activity.icon, color: scheme.primary),
                      const SizedBox(height: 8),
                      Text(r.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: text.titleMedium),
                      const SizedBox(height: 4),
                      Text(
                        '${Fmt.km(r.distanceMeters)} km · ${r.difficulty.label}$near',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: text.bodySmall,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _sectionTitle(BuildContext context, String title,
      {String? actionLabel, VoidCallback? onAction}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 8, 8),
      child: Row(
        children: [
          Expanded(
              child: Text(title, style: Theme.of(context).textTheme.titleMedium)),
          if (actionLabel != null)
            TextButton(onPressed: onAction, child: Text(actionLabel)),
        ],
      ),
    );
  }

  Widget _emptyCard(BuildContext context,
      {required IconData icon,
      required String message,
      required String buttonLabel,
      required VoidCallback onPressed}) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(icon, size: 36, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: onPressed, child: Text(buttonLabel)),
          ],
        ),
      ),
    );
  }
}
