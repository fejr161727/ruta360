import '../../../core/utils/geo_utils.dart';
import 'track_point.dart';

/// Acumula distancia, velocidades y desnivel a partir de puntos GPS,
/// descartando lecturas imprecisas, saltos irreales y el ruido cuando
/// el usuario está quieto.
class TrackingEngine {
  TrackingEngine({
    this.minStepM = 4,
    this.maxAccuracyM = 35,
    this.speedLimitMps = 70,
    this.altitudeThresholdM = 4,
  });

  final double minStepM;
  final double maxAccuracyM;
  final double speedLimitMps;
  final double altitudeThresholdM;

  final List<GeoPoint> points = [];
  TrackPoint? _last;
  bool _gap = false;
  double? _refAltitude;

  double distanceM = 0;
  double maxSpeedMps = 0;
  double currentSpeedMps = 0;
  double ascentM = 0;
  double descentM = 0;

  /// Tras una pausa: el siguiente punto no suma la distancia recorrida
  /// mientras estuvo detenido.
  void markGap() => _gap = true;

  /// Devuelve true si el punto fue aceptado.
  bool add(TrackPoint p) {
    final acc = p.accuracy;
    if (acc != null && acc > maxAccuracyM) return false;

    final last = _last;
    if (last != null) {
      final dt = p.time.difference(last.time).inMilliseconds / 1000;
      if (dt <= 0) return false;

      if (_gap) {
        _gap = false;
        currentSpeedMps = 0;
      } else {
        final d = GeoUtils.distanceMeters(last.geo, p.geo);
        if (d < minStepM) {
          final s = p.speedMps ?? 0;
          currentSpeedMps = s > 0.5 ? s : 0;
          return false;
        }
        final v = d / dt;
        if (v > speedLimitMps) return false;
        distanceM += d;
        final device = p.speedMps;
        currentSpeedMps =
            (device != null && device >= 0 && device <= speedLimitMps)
                ? device
                : v;
        if (currentSpeedMps > maxSpeedMps) maxSpeedMps = currentSpeedMps;
      }
    }

    _updateAltitude(p.altitude);
    points.add(p.geo);
    _last = p;
    return true;
  }

  void _updateAltitude(double? alt) {
    if (alt == null) return;
    final ref = _refAltitude;
    if (ref == null) {
      _refAltitude = alt;
      return;
    }
    final diff = alt - ref;
    if (diff >= altitudeThresholdM) {
      ascentM += diff;
      _refAltitude = alt;
    } else if (diff <= -altitudeThresholdM) {
      descentM += -diff;
      _refAltitude = alt;
    }
  }
}
