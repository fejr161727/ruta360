enum Difficulty {
  easy('easy', 'Fácil'),
  moderate('moderate', 'Moderada'),
  hard('hard', 'Difícil'),
  expert('expert', 'Experto');

  const Difficulty(this.id, this.label);
  final String id;
  final String label;

  static Difficulty fromId(String? id) => Difficulty.values
      .firstWhere((e) => e.id == id, orElse: () => Difficulty.moderate);
}

enum Surface {
  asphalt('asphalt', 'Asfalto'),
  gravel('gravel', 'Tierra / ripio'),
  trail('trail', 'Sendero'),
  mixed('mixed', 'Mixta');

  const Surface(this.id, this.label);
  final String id;
  final String label;

  static Surface fromId(String? id) => Surface.values
      .firstWhere((e) => e.id == id, orElse: () => Surface.mixed);
}

enum ContentVisibility {
  public('public', 'Pública'),
  private('private', 'Privada');

  const ContentVisibility(this.id, this.label);
  final String id;
  final String label;

  static ContentVisibility fromId(String? id) => ContentVisibility.values
      .firstWhere((e) => e.id == id, orElse: () => ContentVisibility.private);
}
