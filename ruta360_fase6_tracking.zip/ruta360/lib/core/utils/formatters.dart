class Fmt {
  const Fmt._();

  static String _two(int n) => n.toString().padLeft(2, '0');

  /// 65 s -> "01:05"; 3725 s -> "1:02:05".
  static String duration(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60);
    final s = d.inSeconds.remainder(60);
    return h > 0 ? '$h:${_two(m)}:${_two(s)}' : '${_two(m)}:${_two(s)}';
  }

  static String km(double meters) => (meters / 1000).toStringAsFixed(2);

  static String kmh(double value) => value.toStringAsFixed(1);

  static String meters(double value) => value.round().toString();

  static String date(DateTime d) => '${_two(d.day)}/${_two(d.month)}/${d.year}';

  static String minutes(int totalMinutes) {
    if (totalMinutes < 60) return '$totalMinutes min';
    final h = totalMinutes ~/ 60;
    final m = totalMinutes % 60;
    return m == 0 ? '$h h' : '$h h $m min';
  }

  /// Ritmo en min/km a partir de m/s: 3 m/s -> "5:33".
  static String pace(double mps) {
    if (mps < 0.3) return '--:--';
    final total = (1000 / mps).round();
    return '${total ~/ 60}:${_two(total % 60)}';
  }
}
