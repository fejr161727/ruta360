"""Configura Android para RUTA360 tras `flutter create`.
- Copia google-services.json a android/app
- Fija applicationId = ec.ruta360.app (debe coincidir con Firebase)
- Añade el plugin de Google Services y el permiso INTERNET
"""
import pathlib
import re
import shutil
import sys

PKG = "ec.ruta360.app"
GS_PLUGIN_VERSION = "4.4.2"

root = pathlib.Path(".")
gs = root / "google-services.json"
if not gs.exists():
    sys.exit("ERROR: falta google-services.json en la raiz del repositorio")
if PKG not in gs.read_text(encoding="utf-8"):
    sys.exit(f"ERROR: google-services.json no corresponde al paquete {PKG}")
shutil.copy(gs, root / "android/app/google-services.json")

# settings.gradle.kts: declarar el plugin
settings = root / "android/settings.gradle.kts"
if not settings.exists():
    sys.exit("ERROR: no se encontro android/settings.gradle.kts (version de Flutter distinta)")
s = settings.read_text(encoding="utf-8")
if "com.google.gms.google-services" not in s:
    s, n = re.subn(
        r'(\n\s*id\("com\.android\.application"\) version [^\n]*)',
        r'\1\n    id("com.google.gms.google-services") version "%s" apply false' % GS_PLUGIN_VERSION,
        s, count=1)
    if n == 0:
        sys.exit("ERROR: no se pudo anadir el plugin en settings.gradle.kts")
    settings.write_text(s, encoding="utf-8")

# app/build.gradle.kts: aplicar plugin, applicationId y minSdk
app = root / "android/app/build.gradle.kts"
if not app.exists():
    sys.exit("ERROR: no se encontro android/app/build.gradle.kts")
a = app.read_text(encoding="utf-8")
if "com.google.gms.google-services" not in a:
    a, n = re.subn(
        r'(\n\s*id\("com\.android\.application"\)[^\n]*)',
        r'\1\n    id("com.google.gms.google-services")',
        a, count=1)
    if n == 0:
        sys.exit("ERROR: no se pudo aplicar el plugin en app/build.gradle.kts")
a, n = re.subn(r'applicationId\s*=\s*"[^"]+"', 'applicationId = "%s"' % PKG, a, count=1)
if n == 0:
    sys.exit("ERROR: no se encontro applicationId")
a = re.sub(r'minSdk\s*=\s*flutter\.minSdkVersion', 'minSdk = 24', a)
app.write_text(a, encoding="utf-8")

# Permisos: INTERNET, ubicacion y servicio en primer plano para grabar actividades
manifest = root / "android/app/src/main/AndroidManifest.xml"
m = manifest.read_text(encoding="utf-8")
for perm in (
    "android.permission.INTERNET",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.ACCESS_COARSE_LOCATION",
    "android.permission.FOREGROUND_SERVICE",
    "android.permission.FOREGROUND_SERVICE_LOCATION",
    "android.permission.WAKE_LOCK",
    "android.permission.POST_NOTIFICATIONS",
):
    if perm not in m:
        m = m.replace(
            "<application",
            '<uses-permission android:name="%s"/>\n    <application' % perm,
            1,
        )
m = re.sub(r'android:label="[^"]*"', 'android:label="RUTA360"', m, count=1)
manifest.write_text(m, encoding="utf-8")

# Icono propio de la app (reemplaza el de Flutter)
res = root / "android/app/src/main/res"
for density in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"):
    src = root / "tool/icons" / f"ic_launcher_{density}.png"
    dst = res / f"mipmap-{density}" / "ic_launcher.png"
    if src.exists() and dst.parent.exists():
        shutil.copy(src, dst)

# Clave de firma de depuracion FIJA: asi cada APK se instala encima del anterior
# y el SHA-1 no cambia (necesario para restringir claves de API).
ks = root / "tool/debug.keystore"
if ks.exists():
    dest = pathlib.Path.home() / ".android"
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copy(ks, dest / "debug.keystore")

print("Android configurado para", PKG)
