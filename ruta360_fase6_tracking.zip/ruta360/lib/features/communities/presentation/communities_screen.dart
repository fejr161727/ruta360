import 'package:flutter/material.dart';
import '../../../shared/widgets/empty_state.dart';

class CommunitiesScreen extends StatelessWidget {
  const CommunitiesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Comunidades')),
      body: const EmptyState(
        icon: Icons.groups_outlined,
        title: 'Comunidades',
        message: 'Grupos, eventos y muro llegan en las Fases 7-8.',
      ),
    );
  }
}
