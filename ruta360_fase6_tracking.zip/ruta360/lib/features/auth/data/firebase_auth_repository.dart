import 'package:firebase_auth/firebase_auth.dart' as fb;

import '../../../core/errors/app_failure.dart';
import '../domain/app_user.dart';
import '../domain/auth_repository.dart';

class FirebaseAuthRepository implements AuthRepository {
  FirebaseAuthRepository([fb.FirebaseAuth? auth])
      : _auth = auth ?? fb.FirebaseAuth.instance;

  final fb.FirebaseAuth _auth;

  AppUser? _map(fb.User? u) => u == null
      ? null
      : AppUser(uid: u.uid, email: u.email ?? '', displayName: u.displayName);

  @override
  Stream<AppUser?> authStateChanges() => _auth.userChanges().map(_map);

  @override
  Future<void> signIn({required String email, required String password}) {
    return _run(() => _auth.signInWithEmailAndPassword(
          email: email.trim(),
          password: password,
        ));
  }

  @override
  Future<void> register({
    required String email,
    required String password,
    required String displayName,
  }) {
    return _run(() async {
      final cred = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      await cred.user?.updateDisplayName(displayName.trim());
      await cred.user?.reload();
    });
  }

  @override
  Future<void> sendPasswordReset(String email) {
    return _run(() => _auth.sendPasswordResetEmail(email: email.trim()));
  }

  @override
  Future<void> signOut() => _run(() => _auth.signOut());

  Future<void> _run(Future<void> Function() action) async {
    try {
      await action();
    } on fb.FirebaseAuthException catch (e) {
      throw AppFailure(_messageFor(e.code));
    } catch (_) {
      throw const AppFailure('Ocurrió un error inesperado. Intenta de nuevo.');
    }
  }

  static String _messageFor(String code) {
    switch (code) {
      case 'invalid-email':
        return 'El correo no es válido.';
      case 'user-disabled':
        return 'Esta cuenta ha sido deshabilitada.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'Correo o contraseña incorrectos.';
      case 'email-already-in-use':
        return 'Ya existe una cuenta con este correo.';
      case 'weak-password':
        return 'La contraseña es muy débil (mínimo 8 caracteres).';
      case 'too-many-requests':
        return 'Demasiados intentos. Espera unos minutos e intenta de nuevo.';
      case 'network-request-failed':
        return 'Sin conexión. Revisa tu internet.';
      case 'operation-not-allowed':
        return 'El acceso con correo no está habilitado en Firebase.';
      default:
        return 'No se pudo completar la operación ($code).';
    }
  }
}
