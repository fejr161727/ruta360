import 'package:flutter/material.dart';
import '../../../shared/widgets/empty_state.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Perfil')),
      body: const EmptyState(
        icon: Icons.person_outline,
        title: 'Perfil',
        message: 'Tu perfil y estadísticas llegan con la autenticación (Fase 3).',
      ),
    );
  }
}
