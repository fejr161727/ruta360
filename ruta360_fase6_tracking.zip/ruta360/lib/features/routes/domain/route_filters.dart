import '../../../core/constants/activity_type.dart';
import '../../../core/constants/route_enums.dart';
import '../../../core/utils/geo_utils.dart';
import 'route_model.dart';

enum RouteSort {
  newest('Más recientes'),
  nearest('Más cercanas'),
  shortest('Más cortas'),
  longest('Más largas');

  const RouteSort(this.label);
  final String label;
}

class RouteFilters {
  const RouteFilters({
    this.query = '',
    this.activity,
    this.difficulty,
    this.surface,
    this.maxKm,
    this.sort = RouteSort.newest,
  });

  final String query;
  final ActivityType? activity;
  final Difficulty? difficulty;
  final Surface? surface;
  final double? maxKm;
  final RouteSort sort;

  bool get hasActive =>
      activity != null ||
      difficulty != null ||
      surface != null ||
      maxKm != null ||
      sort != RouteSort.newest;

  /// Los filtros opcionales se pasan como función para poder limpiarlos (null).
  RouteFilters copyWith({
    String? query,
    ActivityType? Function()? activity,
    Difficulty? Function()? difficulty,
    Surface? Function()? surface,
    double? Function()? maxKm,
    RouteSort? sort,
  }) {
    return RouteFilters(
      query: query ?? this.query,
      activity: activity != null ? activity() : this.activity,
      difficulty: difficulty != null ? difficulty() : this.difficulty,
      surface: surface != null ? surface() : this.surface,
      maxKm: maxKm != null ? maxKm() : this.maxKm,
      sort: sort ?? this.sort,
    );
  }
}

List<RouteModel> applyRouteFilters(
  List<RouteModel> all,
  RouteFilters f, {
  GeoPoint? userPosition,
}) {
  final q = f.query.trim().toLowerCase();
  final out = all.where((r) {
    if (f.activity != null && r.activity != f.activity) return false;
    if (f.difficulty != null && r.difficulty != f.difficulty) return false;
    if (f.surface != null && r.surface != f.surface) return false;
    if (f.maxKm != null && r.distanceMeters / 1000 > f.maxKm!) return false;
    if (q.isNotEmpty &&
        !(r.name.toLowerCase().contains(q) ||
            r.description.toLowerCase().contains(q) ||
            r.ownerName.toLowerCase().contains(q))) {
      return false;
    }
    return true;
  }).toList();

  int byNewest(RouteModel a, RouteModel b) {
    final da = a.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
    final db = b.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
    return db.compareTo(da);
  }

  switch (f.sort) {
    case RouteSort.newest:
      out.sort(byNewest);
    case RouteSort.nearest:
      if (userPosition == null) {
        out.sort(byNewest);
      } else {
        out.sort((a, b) => GeoUtils.distanceMeters(userPosition, a.start)
            .compareTo(GeoUtils.distanceMeters(userPosition, b.start)));
      }
    case RouteSort.shortest:
      out.sort((a, b) => a.distanceMeters.compareTo(b.distanceMeters));
    case RouteSort.longest:
      out.sort((a, b) => b.distanceMeters.compareTo(a.distanceMeters));
  }
  return out;
}
