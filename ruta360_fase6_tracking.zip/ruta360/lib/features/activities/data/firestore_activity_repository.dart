import 'package:cloud_firestore/cloud_firestore.dart' as fs;
import 'package:firebase_core/firebase_core.dart';

import '../../../core/constants/activity_type.dart';
import '../../../core/constants/route_enums.dart';
import '../../../core/errors/firebase_failure.dart';
import '../../../core/utils/polyline_codec.dart';
import '../domain/activity_model.dart';
import '../domain/activity_repository.dart';

class FirestoreActivityRepository implements ActivityRepository {
  FirestoreActivityRepository([fs.FirebaseFirestore? db])
      : _col = (db ?? fs.FirebaseFirestore.instance).collection('activities');

  final fs.CollectionReference<Map<String, dynamic>> _col;

  @override
  Future<String> create(ActivityModel a) async {
    try {
      final doc = await _col.add({
        'ownerId': a.ownerId,
        'ownerName': a.ownerName,
        'type': a.type.id,
        'title': a.title.trim(),
        'description': a.description.trim(),
        'distanceMeters': a.distanceMeters,
        'movingSeconds': a.movingSeconds,
        'avgSpeedMps': a.avgSpeedMps,
        'maxSpeedMps': a.maxSpeedMps,
        'ascentMeters': a.ascentMeters,
        'descentMeters': a.descentMeters,
        'calories': a.calories,
        'difficulty': a.difficulty.id,
        'surface': a.surface.id,
        'visibility': a.visibility.id,
        'startedAt': fs.Timestamp.fromDate(a.startedAt),
        'polyline': PolylineCodec.encode(a.points),
        'routeId': a.routeId,
        'createdAt': fs.FieldValue.serverTimestamp(),
      });
      return doc.id;
    } on FirebaseException catch (e) {
      throw firebaseFailure(e);
    }
  }

  @override
  Future<List<ActivityModel>> myActivities(String uid, {int limit = 100}) async {
    try {
      final snap = await _col.where('ownerId', isEqualTo: uid).limit(limit).get();
      return snap.docs.map(_fromDoc).toList();
    } on FirebaseException catch (e) {
      throw firebaseFailure(e);
    }
  }

  @override
  Future<ActivityModel?> byId(String id) async {
    try {
      final doc = await _col.doc(id).get();
      return doc.exists ? _fromDoc(doc) : null;
    } on FirebaseException catch (e) {
      throw firebaseFailure(e);
    }
  }

  @override
  Future<void> delete(String id) async {
    try {
      await _col.doc(id).delete();
    } on FirebaseException catch (e) {
      throw firebaseFailure(e);
    }
  }

  ActivityModel _fromDoc(fs.DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? const <String, dynamic>{};
    double num0(String k) => (d[k] as num?)?.toDouble() ?? 0;
    return ActivityModel(
      id: doc.id,
      ownerId: (d['ownerId'] as String?) ?? '',
      ownerName: (d['ownerName'] as String?) ?? 'Usuario',
      type: ActivityType.fromId((d['type'] as String?) ?? ''),
      title: (d['title'] as String?) ?? 'Actividad',
      description: (d['description'] as String?) ?? '',
      distanceMeters: num0('distanceMeters'),
      movingSeconds: (d['movingSeconds'] as num?)?.toInt() ?? 0,
      avgSpeedMps: num0('avgSpeedMps'),
      maxSpeedMps: num0('maxSpeedMps'),
      ascentMeters: num0('ascentMeters'),
      descentMeters: num0('descentMeters'),
      calories: num0('calories'),
      difficulty: Difficulty.fromId(d['difficulty'] as String?),
      surface: Surface.fromId(d['surface'] as String?),
      visibility: ContentVisibility.fromId(d['visibility'] as String?),
      startedAt: (d['startedAt'] as fs.Timestamp?)?.toDate() ??
          DateTime.fromMillisecondsSinceEpoch(0),
      points: PolylineCodec.decode((d['polyline'] as String?) ?? ''),
      routeId: d['routeId'] as String?,
      createdAt: (d['createdAt'] as fs.Timestamp?)?.toDate(),
    );
  }
}
