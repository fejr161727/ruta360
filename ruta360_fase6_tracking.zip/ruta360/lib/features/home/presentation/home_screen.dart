import 'package:flutter/material.dart';
import '../../../shared/widgets/empty_state.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Inicio')),
      body: const EmptyState(
        icon: Icons.home_outlined,
        title: 'Inicio',
        message: 'Aquí verás tus rutas cercanas y actividades recientes (Fases 5-6).',
      ),
    );
  }
}
