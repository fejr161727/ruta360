import 'package:flutter/material.dart';

/// Paleta provisional de RUTA360.
class AppColors {
  const AppColors._();
  static const Color primary = Color(0xFF0E7C66);
  static const Color accent = Color(0xFFFF6B2C);
  static const Color darkSurface = Color(0xFF10151A);
}
