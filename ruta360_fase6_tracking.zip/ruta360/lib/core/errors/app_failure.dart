/// Error de negocio con un mensaje listo para mostrar al usuario.
class AppFailure implements Exception {
  const AppFailure(this.message);
  final String message;

  @override
  String toString() => message;
}
