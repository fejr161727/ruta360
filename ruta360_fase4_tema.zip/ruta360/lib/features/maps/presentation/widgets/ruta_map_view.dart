import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../../../../core/config/env.dart';
import '../../../../core/utils/geo_utils.dart';

class MapMarkerData {
  const MapMarkerData({
    required this.point,
    this.color,
    this.icon = Icons.place,
  });

  final GeoPoint point;
  final Color? color;
  final IconData icon;
}

class MapPolylineData {
  const MapPolylineData({
    required this.points,
    this.color = const Color(0xFFFF6B2C),
    this.width = 5,
  });

  final List<GeoPoint> points;
  final Color color;
  final double width;
}

/// Controlador propio: la app no depende del tipo de controlador del proveedor.
class RutaMapController {
  final MapController _inner = MapController();
  bool _ready = false;
  (GeoPoint, double?)? _pending;

  void _onReady() {
    _ready = true;
    final p = _pending;
    if (p != null) {
      _pending = null;
      moveTo(p.$1, zoom: p.$2);
    }
  }

  void moveTo(GeoPoint point, {double? zoom}) {
    if (!_ready) {
      _pending = (point, zoom);
      return;
    }
    _inner.move(
      LatLng(point.lat, point.lng),
      zoom ?? _inner.camera.zoom,
    );
  }

  void dispose() => _inner.dispose();
}

class RutaMapView extends StatelessWidget {
  const RutaMapView({
    super.key,
    required this.controller,
    required this.center,
    this.zoom = 13,
    this.userLocation,
    this.markers = const [],
    this.polylines = const [],
  });

  final RutaMapController controller;
  final GeoPoint center;
  final double zoom;
  final GeoPoint? userLocation;
  final List<MapMarkerData> markers;
  final List<MapPolylineData> polylines;

  @override
  Widget build(BuildContext context) {
    return FlutterMap(
      mapController: controller._inner,
      options: MapOptions(
        initialCenter: LatLng(center.lat, center.lng),
        initialZoom: zoom,
        minZoom: 3,
        maxZoom: 19,
        onMapReady: controller._onReady,
      ),
      children: [
        TileLayer(
          urlTemplate: Env.tileUrlTemplate,
          userAgentPackageName: Env.androidPackage,
        ),
        if (polylines.isNotEmpty)
          PolylineLayer(
            polylines: [
              for (final p in polylines)
                Polyline(
                  points: [for (final g in p.points) LatLng(g.lat, g.lng)],
                  color: p.color,
                  strokeWidth: p.width,
                ),
            ],
          ),
        if (markers.isNotEmpty)
          MarkerLayer(
            markers: [
              for (final m in markers)
                Marker(
                  point: LatLng(m.point.lat, m.point.lng),
                  width: 40,
                  height: 40,
                  alignment: Alignment.topCenter,
                  child: Icon(
                    m.icon,
                    size: 40,
                    color: m.color ?? Theme.of(context).colorScheme.primary,
                  ),
                ),
            ],
          ),
        if (userLocation != null)
          MarkerLayer(
            markers: [
              Marker(
                point: LatLng(userLocation!.lat, userLocation!.lng),
                width: 22,
                height: 22,
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E88E5),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 3),
                    boxShadow: const [
                      BoxShadow(blurRadius: 6, color: Colors.black38),
                    ],
                  ),
                ),
              ),
            ],
          ),
        RichAttributionWidget(
          attributions: [TextSourceAttribution(Env.tileAttribution)],
        ),
      ],
    );
  }
}
