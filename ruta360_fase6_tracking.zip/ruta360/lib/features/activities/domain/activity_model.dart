import 'package:equatable/equatable.dart';

import '../../../core/constants/activity_type.dart';
import '../../../core/constants/route_enums.dart';
import '../../../core/utils/geo_utils.dart';

class ActivityModel extends Equatable {
  const ActivityModel({
    required this.id,
    required this.ownerId,
    required this.ownerName,
    required this.type,
    required this.title,
    required this.description,
    required this.distanceMeters,
    required this.movingSeconds,
    required this.avgSpeedMps,
    required this.maxSpeedMps,
    required this.ascentMeters,
    required this.descentMeters,
    required this.calories,
    required this.difficulty,
    required this.surface,
    required this.visibility,
    required this.startedAt,
    required this.points,
    this.routeId,
    this.createdAt,
  });

  final String id;
  final String ownerId;
  final String ownerName;
  final ActivityType type;
  final String title;
  final String description;
  final double distanceMeters;
  final int movingSeconds;
  final double avgSpeedMps;
  final double maxSpeedMps;
  final double ascentMeters;
  final double descentMeters;
  final double calories;
  final Difficulty difficulty;
  final Surface surface;
  final ContentVisibility visibility;
  final DateTime startedAt;
  final List<GeoPoint> points;
  final String? routeId;
  final DateTime? createdAt;

  @override
  List<Object?> get props => [id, ownerId, title, distanceMeters, startedAt];
}
