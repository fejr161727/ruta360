import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Logo de RUTA360 dibujado por código: anillo "360", punto de ubicación
/// y punto de ruta. Diseño propio, sin recursos de terceros.
class RutaLogo extends StatelessWidget {
  const RutaLogo({super.key, this.size = 72, this.color, this.dotColor});

  final double size;
  final Color? color;
  final Color? dotColor;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _LogoPainter(
          color: color ?? scheme.primary,
          dotColor: dotColor ?? scheme.secondary,
        ),
      ),
    );
  }
}

class _LogoPainter extends CustomPainter {
  _LogoPainter({required this.color, required this.dotColor});

  final Color color;
  final Color dotColor;

  @override
  void paint(Canvas canvas, Size size) {
    final n = size.width;
    final c = Offset(n / 2, n / 2);
    final r = n * 0.38;
    final w = n * 0.10;
    const start = -math.pi / 4; // -45°
    const sweep = 1.5 * math.pi; // 270°

    final stroke = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = w
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(Rect.fromCircle(center: c, radius: r), start, sweep, false,
        stroke);

    final fill = Paint()..color = color;
    canvas.drawCircle(c, n * 0.10, fill);

    const midGap = start + sweep + (2 * math.pi - sweep) / 2;
    final gapPoint = Offset(c.dx + r * math.cos(midGap), c.dy + r * math.sin(midGap));
    canvas.drawCircle(gapPoint, n * 0.065, Paint()..color = dotColor);
  }

  @override
  bool shouldRepaint(_LogoPainter old) =>
      old.color != color || old.dotColor != dotColor;
}
