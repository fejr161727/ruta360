/// Configuración inyectada en compilación (nunca se guardan claves en el repo).
/// Ejecutar con: flutter run --dart-define-from-file=env.json
class Env {
  const Env._();

  /// Token público de Mapbox (pk.*). Se usará en la Fase 4.
  static const String mapboxAccessToken =
      String.fromEnvironment('MAPBOX_ACCESS_TOKEN', defaultValue: '');

  static bool get hasMapbox => mapboxAccessToken.isNotEmpty;

  /// Valores provisionales (reemplazar antes de publicar).
  static const String appName = 'RUTA360';
  static const String androidPackage = 'com.example.ruta360';
  static const String iosBundleId = 'com.example.ruta360';
}
