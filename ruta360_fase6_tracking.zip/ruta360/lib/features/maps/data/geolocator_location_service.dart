import 'dart:async';

import 'package:flutter/foundation.dart'
    show TargetPlatform, defaultTargetPlatform;
import 'package:geolocator/geolocator.dart';

import '../../../core/utils/geo_utils.dart';
import '../../activities/domain/track_point.dart';
import '../domain/location_service.dart';

class GeolocatorLocationService implements LocationService {
  const GeolocatorLocationService();

  @override
  Future<void> ensurePermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw const LocationFailure(
        LocationIssue.serviceDisabled,
        'El GPS está desactivado. Actívalo para continuar.',
      );
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      throw const LocationFailure(
        LocationIssue.denied,
        'Necesitamos el permiso de ubicación para continuar.',
      );
    }
    if (permission == LocationPermission.deniedForever) {
      throw const LocationFailure(
        LocationIssue.deniedForever,
        'El permiso de ubicación está bloqueado. Actívalo en los ajustes de la app.',
      );
    }
  }

  @override
  Future<GeoPoint> currentPosition() async {
    await ensurePermission();
    try {
      final p = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 20),
        ),
      );
      return GeoPoint(p.latitude, p.longitude);
    } on TimeoutException {
      throw const LocationFailure(
        LocationIssue.unavailable,
        'No se pudo obtener tu ubicación a tiempo. Intenta en un lugar abierto.',
      );
    } catch (_) {
      throw const LocationFailure(
        LocationIssue.unavailable,
        'No se pudo obtener tu ubicación.',
      );
    }
  }

  @override
  Stream<TrackPoint> positionStream() {
    final LocationSettings settings;
    if (defaultTargetPlatform == TargetPlatform.android) {
      settings = AndroidSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 0,
        intervalDuration: const Duration(seconds: 2),
        foregroundNotificationConfig: const ForegroundNotificationConfig(
          notificationTitle: 'RUTA360',
          notificationText: 'Registrando tu actividad…',
          enableWakeLock: true,
          setOngoing: true,
        ),
      );
    } else if (defaultTargetPlatform == TargetPlatform.iOS) {
      settings = AppleSettings(
        accuracy: LocationAccuracy.best,
        activityType: ActivityType.fitness,
        distanceFilter: 0,
        pauseLocationUpdatesAutomatically: false,
        showBackgroundLocationIndicator: true,
        allowBackgroundLocationUpdates: true,
      );
    } else {
      settings = const LocationSettings(accuracy: LocationAccuracy.best);
    }

    return Geolocator.getPositionStream(locationSettings: settings).map(
      (p) => TrackPoint(
        lat: p.latitude,
        lng: p.longitude,
        time: p.timestamp,
        altitude: p.altitude,
        speedMps: p.speed >= 0 ? p.speed : null,
        accuracy: p.accuracy,
      ),
    );
  }

  @override
  Future<void> openSettings(LocationIssue issue) async {
    if (issue == LocationIssue.serviceDisabled) {
      await Geolocator.openLocationSettings();
    } else {
      await Geolocator.openAppSettings();
    }
  }
}
