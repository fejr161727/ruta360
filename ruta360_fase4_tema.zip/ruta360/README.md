# RUTA360 (Fase 2 — Proyecto base)

## Requisitos
Flutter 3.22+ (Dart 3.4+), Android Studio / Xcode.

## Crear plataformas (una sola vez)
Este paquete trae `lib/`, `test/` y `pubspec.yaml`. En la carpeta del proyecto:

    flutter create --org com.example --project-name ruta360 --platforms android,ios .
    flutter pub get
    flutter test
    flutter run

`com.example.ruta360` es un package name PROVISIONAL: cámbialo antes de conectar Firebase o publicar.

## Claves
Crea `env.json` (ignorado por git):

    { "MAPBOX_ACCESS_TOKEN": "pk.xxxxx" }

y ejecuta `flutter run --dart-define-from-file=env.json`.

## Fase 3 — Autenticación
Firebase Auth (correo/contraseña). Requiere `google-services.json` del paquete `ec.ruta360.app`
en la raíz del repositorio; `tool/patch_android.py` lo coloca y configura Gradle al compilar.

## Fase 4 — Mapa y ubicación
Mapa con `flutter_map` (teselas OpenStreetMap para desarrollo). El widget `RutaMapView` y el
`LocationService` aíslan al proveedor, así se puede cambiar a Mapbox/MapTiler sin tocar las pantallas
(`--dart-define=TILE_URL=...`). Permisos de ubicación en primer plano; el segundo plano llega en la Fase 6.

## Diseño
Fondo blanco por defecto, azul `#1565C0` como color de marca; tema oscuro opcional (Perfil → Apariencia).
El logo (`RutaLogo` y `tool/icons/`) es un diseño propio generado por código.

## Firma de depuración
`tool/debug.keystore` es una clave de DEPURACIÓN (contraseña `android`, alias `androiddebugkey`), pública por diseño.
No sirve para publicar: la clave de Play Store se genera aparte (Fase 11) y NUNCA se sube al repositorio.
