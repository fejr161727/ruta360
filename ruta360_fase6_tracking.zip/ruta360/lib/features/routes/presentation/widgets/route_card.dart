import 'package:flutter/material.dart';

import '../../../../core/constants/route_enums.dart';
import '../../../../core/utils/formatters.dart';
import '../../domain/route_model.dart';

class RouteCard extends StatelessWidget {
  const RouteCard({
    super.key,
    required this.route,
    required this.onTap,
    this.distanceFromUserM,
    this.trailing,
  });

  final RouteModel route;
  final VoidCallback onTap;
  final double? distanceFromUserM;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final scheme = Theme.of(context).colorScheme;
    final near = distanceFromUserM == null
        ? ''
        : ' · a ${Fmt.km(distanceFromUserM!)} km de ti';
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: scheme.primary.withOpacity(0.12),
                child: Icon(route.activity.icon, color: scheme.primary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(route.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: text.titleMedium),
                    const SizedBox(height: 2),
                    Text(
                      '${Fmt.km(route.distanceMeters)} km · '
                      '${route.difficulty.label} · ${route.surface.label}$near',
                      style: text.bodySmall,
                    ),
                    Text('por ${route.ownerName}', style: text.bodySmall),
                    if (route.visibility == ContentVisibility.private)
                      Row(
                        children: [
                          Icon(Icons.lock_outline,
                              size: 14, color: scheme.onSurfaceVariant),
                          const SizedBox(width: 4),
                          Text('Privada', style: text.bodySmall),
                        ],
                      ),
                  ],
                ),
              ),
              if (trailing != null) trailing!,
            ],
          ),
        ),
      ),
    );
  }
}
