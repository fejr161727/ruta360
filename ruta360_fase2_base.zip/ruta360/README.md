# RUTA360 (Fase 2 — Proyecto base)

## Requisitos
Flutter 3.22+ (Dart 3.4+), Android Studio / Xcode.

## Crear plataformas (una sola vez)
Este paquete trae `lib/`, `test/` y `pubspec.yaml`. En la carpeta del proyecto:

    flutter create --org com.example --project-name ruta360 --platforms android,ios .
    flutter pub get
    flutter test
    flutter run

`com.example.ruta360` es un package name PROVISIONAL: cámbialo antes de conectar Firebase o publicar.

## Claves
Crea `env.json` (ignorado por git):

    { "MAPBOX_ACCESS_TOKEN": "pk.xxxxx" }

y ejecuta `flutter run --dart-define-from-file=env.json`.
