import 'package:cloud_firestore/cloud_firestore.dart' as fs;
import 'package:firebase_core/firebase_core.dart';

import '../../../core/constants/activity_type.dart';
import '../../../core/constants/route_enums.dart';
import '../../../core/errors/app_failure.dart';
import '../../../core/errors/firebase_failure.dart';
import '../../../core/utils/geo_utils.dart';
import '../../../core/utils/polyline_codec.dart';
import '../domain/route_model.dart';
import '../domain/route_repository.dart';

class FirestoreRouteRepository implements RouteRepository {
  FirestoreRouteRepository([fs.FirebaseFirestore? db])
      : _col = (db ?? fs.FirebaseFirestore.instance).collection('routes');

  final fs.CollectionReference<Map<String, dynamic>> _col;

  @override
  Future<String> create(RouteModel r) async {
    if (r.points.length < 2) {
      throw const AppFailure('La ruta necesita al menos 2 puntos.');
    }
    try {
      final doc = await _col.add({
        'ownerId': r.ownerId,
        'ownerName': r.ownerName,
        'name': r.name.trim(),
        'description': r.description.trim(),
        'activity': r.activity.id,
        'difficulty': r.difficulty.id,
        'surface': r.surface.id,
        'distanceMeters': r.distanceMeters,
        'ascentMeters': r.ascentMeters,
        'startLat': r.start.lat,
        'startLng': r.start.lng,
        'polyline': PolylineCodec.encode(r.points),
        'visibility': r.visibility.id,
        'ratingAvg': 0,
        'ratingCount': 0,
        'completedCount': 0,
        'createdAt': fs.FieldValue.serverTimestamp(),
      });
      return doc.id;
    } on FirebaseException catch (e) {
      throw firebaseFailure(e);
    }
  }

  @override
  Future<List<RouteModel>> publicRoutes({int limit = 100}) {
    return _query(_col.where('visibility', isEqualTo: 'public').limit(limit));
  }

  @override
  Future<List<RouteModel>> myRoutes(String uid, {int limit = 100}) {
    return _query(_col.where('ownerId', isEqualTo: uid).limit(limit));
  }

  @override
  Future<RouteModel?> byId(String id) async {
    try {
      final doc = await _col.doc(id).get();
      return _fromDoc(doc);
    } on FirebaseException catch (e) {
      throw firebaseFailure(e);
    }
  }

  @override
  Future<void> delete(String id) async {
    try {
      await _col.doc(id).delete();
    } on FirebaseException catch (e) {
      throw firebaseFailure(e);
    }
  }

  Future<List<RouteModel>> _query(
    fs.Query<Map<String, dynamic>> query,
  ) async {
    try {
      final snap = await query.get();
      return [
        for (final doc in snap.docs)
          if (_fromDoc(doc) != null) _fromDoc(doc)!,
      ];
    } on FirebaseException catch (e) {
      throw firebaseFailure(e);
    }
  }

  RouteModel? _fromDoc(fs.DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data();
    if (d == null) return null;
    final points = PolylineCodec.decode((d['polyline'] as String?) ?? '');
    if (points.length < 2) return null;
    return RouteModel(
      id: doc.id,
      ownerId: (d['ownerId'] as String?) ?? '',
      ownerName: (d['ownerName'] as String?) ?? 'Usuario',
      name: (d['name'] as String?) ?? 'Ruta sin nombre',
      description: (d['description'] as String?) ?? '',
      activity: ActivityType.fromId((d['activity'] as String?) ?? ''),
      difficulty: Difficulty.fromId(d['difficulty'] as String?),
      surface: Surface.fromId(d['surface'] as String?),
      distanceMeters: (d['distanceMeters'] as num?)?.toDouble() ??
          GeoUtils.polylineLengthMeters(points),
      ascentMeters: (d['ascentMeters'] as num?)?.toDouble() ?? 0,
      points: points,
      visibility: ContentVisibility.fromId(d['visibility'] as String?),
      createdAt: (d['createdAt'] as fs.Timestamp?)?.toDate(),
    );
  }
}
