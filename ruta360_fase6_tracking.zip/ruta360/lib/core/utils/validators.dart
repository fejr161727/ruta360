class Validators {
  const Validators._();

  static final RegExp _emailRegex =
      RegExp(r'^[\w.+\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}$');

  static String? email(String? value) {
    final v = value?.trim() ?? '';
    if (v.isEmpty) return 'Ingresa tu correo';
    if (!_emailRegex.hasMatch(v)) return 'Correo no válido';
    return null;
  }

  static String? password(String? value) {
    final v = value ?? '';
    if (v.isEmpty) return 'Ingresa tu contraseña';
    if (v.length < 8) return 'Mínimo 8 caracteres';
    return null;
  }

  static String? loginPassword(String? value) {
    if (value == null || value.isEmpty) return 'Ingresa tu contraseña';
    return null;
  }

  static String? confirmPassword(String? value, String original) {
    if (value == null || value.isEmpty) return 'Confirma tu contraseña';
    if (value != original) return 'Las contraseñas no coinciden';
    return null;
  }

  static String? displayName(String? value) {
    final v = value?.trim() ?? '';
    if (v.length < 2) return 'Ingresa tu nombre (mínimo 2 letras)';
    if (v.length > 50) return 'Máximo 50 caracteres';
    return null;
  }

  static String? requiredText(
    String? value, {
    required String label,
    int min = 3,
    int max = 80,
  }) {
    final v = value?.trim() ?? '';
    if (v.length < min) return '$label: mínimo $min caracteres';
    if (v.length > max) return '$label: máximo $max caracteres';
    return null;
  }
}
