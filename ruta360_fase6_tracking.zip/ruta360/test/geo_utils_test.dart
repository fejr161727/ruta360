import 'package:flutter_test/flutter_test.dart';
import 'package:ruta360/core/utils/geo_utils.dart';

void main() {
  test('distancia entre el mismo punto es 0', () {
    const p = GeoPoint(-0.18, -78.47);
    expect(GeoUtils.distanceMeters(p, p), 0);
  });

  test('1 grado de latitud ≈ 111.2 km', () {
    final d = GeoUtils.distanceMeters(const GeoPoint(0, 0), const GeoPoint(1, 0));
    expect(d, closeTo(111195, 300));
  });

  test('longitud de polilínea suma segmentos', () {
    final pts = [const GeoPoint(0, 0), const GeoPoint(1, 0), const GeoPoint(2, 0)];
    expect(GeoUtils.polylineLengthMeters(pts), closeTo(222390, 600));
  });
}
