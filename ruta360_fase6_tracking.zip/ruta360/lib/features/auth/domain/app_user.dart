import 'package:equatable/equatable.dart';

class AppUser extends Equatable {
  const AppUser({required this.uid, required this.email, this.displayName});

  final String uid;
  final String email;
  final String? displayName;

  String get initial {
    final source = (displayName?.trim().isNotEmpty ?? false)
        ? displayName!.trim()
        : email;
    return source.isEmpty ? '?' : source[0].toUpperCase();
  }

  @override
  List<Object?> get props => [uid, email, displayName];
}
