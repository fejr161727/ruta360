import 'activity_model.dart';

abstract class ActivityRepository {
  Future<String> create(ActivityModel activity);
  Future<List<ActivityModel>> myActivities(String uid, {int limit = 100});
  Future<ActivityModel?> byId(String id);
  Future<void> delete(String id);
}
