/// Configuración inyectada en compilación (nunca se guardan claves en el repo).
/// Ejecutar con: flutter run --dart-define-from-file=env.json
class Env {
  const Env._();

  /// Token público de Mapbox (pk.*). Se usará en la Fase 4.
  static const String mapboxAccessToken =
      String.fromEnvironment('MAPBOX_ACCESS_TOKEN', defaultValue: '');

  static bool get hasMapbox => mapboxAccessToken.isNotEmpty;

  /// Teselas del mapa. OpenStreetMap sirve para desarrollo y pruebas; antes de
  /// publicar con muchos usuarios, cambia a un proveedor con plan propio
  /// (Mapbox, MapTiler...) definiendo TILE_URL y TILE_ATTRIBUTION.
  static const String tileUrlTemplate = String.fromEnvironment(
    'TILE_URL',
    defaultValue: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
  );
  static const String tileAttribution = String.fromEnvironment(
    'TILE_ATTRIBUTION',
    defaultValue: '© OpenStreetMap contributors',
  );

  /// Valores provisionales (reemplazar antes de publicar).
  static const String appName = 'RUTA360';
  static const String androidPackage = 'ec.ruta360.app';
  static const String iosBundleId = 'ec.ruta360.app';
}
