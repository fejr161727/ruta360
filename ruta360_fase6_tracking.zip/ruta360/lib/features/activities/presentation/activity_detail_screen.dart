import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/errors/app_failure.dart';
import '../../../core/utils/formatters.dart';
import '../../../shared/widgets/async_error_view.dart';
import '../../../shared/widgets/empty_state.dart';
import '../../auth/presentation/auth_providers.dart';
import '../../maps/presentation/widgets/ruta_map_view.dart';
import '../domain/activity_model.dart';
import 'activity_providers.dart';
import 'widgets/activity_stats.dart';

class ActivityDetailScreen extends ConsumerWidget {
  const ActivityDetailScreen({super.key, required this.activityId});

  final String activityId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(activityByIdProvider(activityId));
    return Scaffold(
      appBar: AppBar(title: const Text('Actividad')),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => AsyncErrorView(
            error: e,
            onRetry: () => ref.invalidate(activityByIdProvider(activityId))),
        data: (a) => a == null
            ? const EmptyState(
                icon: Icons.search_off,
                title: 'Actividad no encontrada',
                message: 'Puede que haya sido eliminada.')
            : _Body(activity: a),
      ),
    );
  }
}

class _Body extends ConsumerStatefulWidget {
  const _Body({required this.activity});

  final ActivityModel activity;

  @override
  ConsumerState<_Body> createState() => _BodyState();
}

class _BodyState extends ConsumerState<_Body> {
  final _map = RutaMapController();
  bool _deleting = false;

  @override
  void initState() {
    super.initState();
    _map.fitTo(widget.activity.points, padding: 40);
  }

  @override
  void dispose() {
    _map.dispose();
    super.dispose();
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Eliminar actividad'),
        content: const Text('Esta acción no se puede deshacer.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar')),
          FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Eliminar')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _deleting = true);
    try {
      await ref.read(activityRepositoryProvider).delete(widget.activity.id);
      ref.invalidate(myActivitiesProvider);
      if (mounted) context.pop();
    } on AppFailure catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.message)));
      }
    } finally {
      if (mounted) setState(() => _deleting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.activity;
    final text = Theme.of(context).textTheme;
    final isOwner = ref.watch(authStateProvider).valueOrNull?.uid == a.ownerId;
    return ListView(
      children: [
        if (a.points.length >= 2)
          SizedBox(
            height: 260,
            child: RutaMapView(
              controller: _map,
              center: a.points.first,
              zoom: 14,
              polylines: [MapPolylineData(points: a.points)],
              markers: [
                MapMarkerData(
                    point: a.points.first,
                    icon: Icons.trip_origin,
                    color: Colors.green,
                    size: 24,
                    centered: true),
                MapMarkerData(
                    point: a.points.last,
                    icon: Icons.location_on,
                    color: Colors.red),
              ],
            ),
          ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(a.title, style: text.headlineSmall),
              const SizedBox(height: 4),
              Text('${a.type.label} · ${Fmt.date(a.startedAt)}',
                  style: text.bodySmall),
              const SizedBox(height: 16),
              ActivityStats(
                type: a.type,
                distanceM: a.distanceMeters,
                elapsed: Duration(seconds: a.movingSeconds),
                avgSpeedMps: a.avgSpeedMps,
                maxSpeedMps: a.maxSpeedMps,
                ascentM: a.ascentMeters,
                calories: a.calories,
              ),
              if (a.description.trim().isNotEmpty) ...[
                const SizedBox(height: 16),
                Text(a.description),
              ],
              if (isOwner) ...[
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _deleting ? null : _delete,
                        icon: const Icon(Icons.delete_outline),
                        label: const Text('Eliminar actividad'),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}
