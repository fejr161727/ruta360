import 'package:flutter/foundation.dart'
    show TargetPlatform, defaultTargetPlatform;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../core/constants/activity_type.dart';
import '../../../core/router/app_router.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/geo_utils.dart';
import '../../maps/presentation/location_providers.dart';
import '../../maps/presentation/map_defaults.dart';
import '../../maps/presentation/widgets/ruta_map_view.dart';
import '../../routes/presentation/routes_providers.dart';
import 'tracker_notifier.dart';
import 'widgets/activity_stats.dart';

class ActivitiesScreen extends ConsumerStatefulWidget {
  const ActivitiesScreen({super.key});

  @override
  ConsumerState<ActivitiesScreen> createState() => _ActivitiesScreenState();
}

class _ActivitiesScreenState extends ConsumerState<ActivitiesScreen> {
  final _map = RutaMapController();
  GeoPoint? _idlePosition;
  ActivityType? _picked;
  bool _starting = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _locateIdle());
  }

  @override
  void dispose() {
    _map.dispose();
    super.dispose();
  }

  Future<void> _locateIdle() async {
    try {
      final p = await ref.read(locationServiceProvider).currentPosition();
      if (!mounted) return;
      setState(() => _idlePosition = p);
      _map.moveTo(p, zoom: 15);
    } catch (_) {
      // Sin ubicación todavía: el permiso se pedirá al iniciar.
    }
  }

  Future<void> _start(ActivityType type) async {
    setState(() => _starting = true);
    try {
      if (defaultTargetPlatform == TargetPlatform.android) {
        // Android 13+: necesario para ver la notificación de "Registrando…".
        await Permission.notification.request();
      }
      final guide = ref.read(guidedRouteProvider);
      await ref.read(trackerProvider.notifier).start(type, routeId: guide?.id);
    } finally {
      if (mounted) setState(() => _starting = false);
    }
  }

  Future<void> _confirmFinish() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Finalizar actividad'),
        content: const Text('¿Quieres terminar y revisar tu actividad?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Seguir')),
          FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Finalizar')),
        ],
      ),
    );
    if (ok == true) ref.read(trackerProvider.notifier).finish();
  }

  Future<void> _confirmDiscard() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Descartar actividad'),
        content: const Text('Se perderá el recorrido registrado.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar')),
          FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Descartar')),
        ],
      ),
    );
    if (ok == true) ref.read(trackerProvider.notifier).reset();
  }

  @override
  Widget build(BuildContext context) {
    final t = ref.watch(trackerProvider);
    final guide = ref.watch(guidedRouteProvider);
    final type = t.isActive || t.status == TrackerStatus.finished
        ? t.type
        : (_picked ?? guide?.activity ?? ActivityType.cycling);

    ref.listen<TrackerState>(trackerProvider, (prev, next) {
      if (prev?.status != TrackerStatus.finished &&
          next.status == TrackerStatus.finished) {
        context.push(AppRoutes.activitySummary);
      }
      final p = next.lastPoint;
      if (p != null && next.status == TrackerStatus.running) {
        _map.moveTo(p.geo, zoom: prev?.lastPoint == null ? 17 : null);
      }
      if (next.error != null && prev?.error != next.error) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(next.error!.message)));
        ref.read(trackerProvider.notifier).clearError();
      }
    });

    final scheme = Theme.of(context).colorScheme;
    final userPoint = t.lastPoint?.geo ?? _idlePosition;

    return Scaffold(
      appBar: AppBar(title: const Text('Registrar')),
      body: Stack(
        children: [
          RutaMapView(
            controller: _map,
            center: userPoint ?? kDefaultMapCenter,
            zoom: userPoint == null ? 12 : 15,
            userLocation: userPoint,
            polylines: [
              if (guide != null && !t.isActive)
                MapPolylineData(
                    points: guide.points,
                    color: scheme.primary.withOpacity(0.7),
                    width: 4),
              if (guide != null && t.isActive)
                MapPolylineData(
                    points: guide.points,
                    color: scheme.primary.withOpacity(0.5),
                    width: 4),
              MapPolylineData(points: t.points),
            ],
            markers: [
              if (guide != null)
                MapMarkerData(
                    point: guide.start,
                    icon: Icons.trip_origin,
                    color: Colors.green,
                    size: 24,
                    centered: true),
              if (guide != null)
                MapMarkerData(
                    point: guide.end,
                    icon: Icons.location_on,
                    color: Colors.red),
            ],
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: SafeArea(
              child: Card(
                margin: const EdgeInsets.all(12),
                elevation: 4,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: _panel(t, type, guide?.name),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _panel(TrackerState t, ActivityType type, String? guideName) {
    final text = Theme.of(context).textTheme;

    switch (t.status) {
      case TrackerStatus.idle:
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  for (final a in ActivityType.values)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        avatar: Icon(a.icon, size: 18),
                        label: Text(a.label),
                        selected: type == a,
                        onSelected: (_) => setState(() => _picked = a),
                      ),
                    ),
                ],
              ),
            ),
            if (guideName != null) ...[
              const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerLeft,
                child: InputChip(
                  avatar: const Icon(Icons.route, size: 18),
                  label: Text('Siguiendo: $guideName'),
                  onDeleted: () =>
                      ref.read(guidedRouteProvider.notifier).state = null,
                ),
              ),
            ],
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: _starting ? null : () => _start(type),
              icon: const Icon(Icons.play_arrow),
              label: Text(_starting ? 'Iniciando…' : 'INICIAR'),
            ),
          ],
        );

      case TrackerStatus.running:
      case TrackerStatus.paused:
        final paused = t.status == TrackerStatus.paused;
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(Fmt.duration(t.elapsed),
                    style: text.displaySmall
                        ?.copyWith(fontWeight: FontWeight.w700)),
                Chip(
                  avatar: Icon(t.type.icon, size: 18),
                  label: Text(paused ? 'En pausa' : t.type.label),
                ),
              ],
            ),
            const SizedBox(height: 8),
            ActivityStats(
              type: t.type,
              distanceM: t.distanceM,
              elapsed: t.elapsed,
              avgSpeedMps: t.avgSpeedMps,
              maxSpeedMps: t.maxSpeedMps,
              ascentM: t.ascentM,
              calories: t.calories,
              currentSpeedMps: t.currentSpeedMps,
              showTime: false,
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: FilledButton.tonalIcon(
                    onPressed: () {
                      final n = ref.read(trackerProvider.notifier);
                      paused ? n.resume() : n.pause();
                    },
                    icon: Icon(paused ? Icons.play_arrow : Icons.pause),
                    label: Text(paused ? 'CONTINUAR' : 'PAUSAR'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: Theme.of(context).colorScheme.error,
                      foregroundColor: Theme.of(context).colorScheme.onError,
                    ),
                    onPressed: _confirmFinish,
                    icon: const Icon(Icons.stop),
                    label: const Text('FINALIZAR'),
                  ),
                ),
              ],
            ),
          ],
        );

      case TrackerStatus.finished:
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Actividad terminada, sin guardar', style: text.titleMedium),
            const SizedBox(height: 8),
            Text('${Fmt.km(t.distanceM)} km · ${Fmt.duration(t.elapsed)}'),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () => context.push(AppRoutes.activitySummary),
              child: const Text('Revisar y guardar'),
            ),
            TextButton(
              onPressed: _confirmDiscard,
              child: const Text('Descartar'),
            ),
          ],
        );
    }
  }
}
