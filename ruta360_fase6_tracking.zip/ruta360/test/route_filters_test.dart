import 'package:flutter_test/flutter_test.dart';
import 'package:ruta360/core/constants/activity_type.dart';
import 'package:ruta360/core/constants/route_enums.dart';
import 'package:ruta360/core/utils/geo_utils.dart';
import 'package:ruta360/features/routes/domain/route_filters.dart';
import 'package:ruta360/features/routes/domain/route_model.dart';

RouteModel route(
  String id, {
  ActivityType activity = ActivityType.cycling,
  Difficulty difficulty = Difficulty.moderate,
  double km = 10,
  String name = 'Ruta',
  GeoPoint start = const GeoPoint(-0.18, -78.47),
  DateTime? createdAt,
}) {
  return RouteModel(
    id: id,
    ownerId: 'u1',
    ownerName: 'Fabian',
    name: name,
    description: '',
    activity: activity,
    difficulty: difficulty,
    surface: Surface.mixed,
    distanceMeters: km * 1000,
    ascentMeters: 0,
    points: [start, GeoPoint(start.lat + 0.01, start.lng)],
    visibility: ContentVisibility.public,
    createdAt: createdAt,
  );
}

void main() {
  final all = [
    route('a', activity: ActivityType.mtb, km: 25, name: 'Chaquiñán'),
    route('b', activity: ActivityType.running, km: 5, name: 'Parque La Carolina'),
    route('c',
        difficulty: Difficulty.hard,
        km: 60,
        start: const GeoPoint(-0.5, -78.4),
        name: 'Cotopaxi'),
  ];

  test('filtra por actividad', () {
    final r = applyRouteFilters(
        all, const RouteFilters(activity: ActivityType.running));
    expect(r.map((e) => e.id), ['b']);
  });

  test('filtra por distancia máxima', () {
    final r = applyRouteFilters(all, const RouteFilters(maxKm: 30));
    expect(r.map((e) => e.id).toSet(), {'a', 'b'});
  });

  test('busca por nombre sin distinguir mayúsculas', () {
    final r = applyRouteFilters(all, const RouteFilters(query: 'chaqui'));
    expect(r.map((e) => e.id), ['a']);
  });

  test('ordena por cercanía al usuario', () {
    final r = applyRouteFilters(
      all,
      const RouteFilters(sort: RouteSort.nearest),
      userPosition: const GeoPoint(-0.49, -78.4),
    );
    expect(r.first.id, 'c');
  });

  test('ordena de más corta a más larga', () {
    final r = applyRouteFilters(
        all, const RouteFilters(sort: RouteSort.shortest));
    expect(r.map((e) => e.id), ['b', 'a', 'c']);
  });

  test('copyWith puede limpiar un filtro', () {
    const f = RouteFilters(activity: ActivityType.mtb);
    expect(f.copyWith(activity: () => null).activity, isNull);
  });
}
