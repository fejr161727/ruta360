import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/activity_type.dart';
import '../../../../core/constants/route_enums.dart';
import '../../domain/route_filters.dart';
import '../route_filters_provider.dart';

class RouteFilterSheet extends ConsumerStatefulWidget {
  const RouteFilterSheet({super.key});

  @override
  ConsumerState<RouteFilterSheet> createState() => _RouteFilterSheetState();
}

class _RouteFilterSheetState extends ConsumerState<RouteFilterSheet> {
  late RouteFilters _draft = ref.read(routeFiltersProvider);

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final maxKm = _draft.maxKm;
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        8,
        20,
        20 + MediaQuery.of(context).viewInsets.bottom,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Filtrar rutas', style: text.titleLarge),
            const SizedBox(height: 16),
            Text('Actividad', style: text.titleSmall),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                for (final a in ActivityType.values)
                  FilterChip(
                    avatar: Icon(a.icon, size: 18),
                    label: Text(a.label),
                    selected: _draft.activity == a,
                    onSelected: (sel) => setState(() => _draft =
                        _draft.copyWith(activity: () => sel ? a : null)),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Text('Dificultad', style: text.titleSmall),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                for (final d in Difficulty.values)
                  FilterChip(
                    label: Text(d.label),
                    selected: _draft.difficulty == d,
                    onSelected: (sel) => setState(() => _draft =
                        _draft.copyWith(difficulty: () => sel ? d : null)),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Text('Superficie', style: text.titleSmall),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                for (final s in Surface.values)
                  FilterChip(
                    label: Text(s.label),
                    selected: _draft.surface == s,
                    onSelected: (sel) => setState(() => _draft =
                        _draft.copyWith(surface: () => sel ? s : null)),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              maxKm == null
                  ? 'Distancia máxima: sin límite'
                  : 'Distancia máxima: ${maxKm.round()} km',
              style: text.titleSmall,
            ),
            Slider(
              min: 5,
              max: 100,
              divisions: 19,
              value: (maxKm ?? 100).clamp(5, 100).toDouble(),
              label: maxKm == null ? 'Sin límite' : '${maxKm.round()} km',
              onChanged: (v) => setState(() => _draft = _draft.copyWith(
                  maxKm: () => v >= 100 ? null : v.roundToDouble())),
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<RouteSort>(
              value: _draft.sort,
              decoration: const InputDecoration(labelText: 'Ordenar por'),
              items: [
                for (final s in RouteSort.values)
                  DropdownMenuItem(value: s, child: Text(s.label)),
              ],
              onChanged: (s) {
                if (s != null) {
                  setState(() => _draft = _draft.copyWith(sort: s));
                }
              },
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () =>
                        setState(() => _draft = RouteFilters(query: _draft.query)),
                    child: const Text('Limpiar'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton(
                    onPressed: () {
                      ref.read(routeFiltersProvider.notifier).set(_draft);
                      Navigator.of(context).pop();
                    },
                    child: const Text('Aplicar'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
