import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Usa google-services.json (Android) / GoogleService-Info.plist (iOS).
  // Si aún no existen, la app abre igual; Firebase se activa en la Fase 3.
  try {
    await Firebase.initializeApp();
  } catch (e) {
    debugPrint('Firebase no configurado todavía: $e');
  }
  runApp(const ProviderScope(child: Ruta360App()));
}
