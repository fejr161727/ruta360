import 'package:flutter_test/flutter_test.dart';
import 'package:ruta360/core/utils/formatters.dart';
import 'package:ruta360/core/utils/geo_utils.dart';

void main() {
  final line = [
    for (var i = 0; i < 60; i++) GeoPoint(-0.18 + i * 0.0001, -78.47),
  ]; // ~650 m

  test('recorta el inicio y el final', () {
    final trimmed = GeoUtils.trimEnds(line, 200);
    expect(trimmed.length, greaterThan(2));
    expect(GeoUtils.distanceMeters(line.first, trimmed.first),
        greaterThanOrEqualTo(199));
    expect(GeoUtils.distanceMeters(line.last, trimmed.last),
        greaterThanOrEqualTo(199));
  });

  test('si es muy corto no publica trazado', () {
    expect(GeoUtils.trimEnds(line.take(10).toList(), 200), isEmpty);
  });

  test('ritmo min/km', () {
    expect(Fmt.pace(3.0), '5:33');
    expect(Fmt.pace(0), '--:--');
  });
}
