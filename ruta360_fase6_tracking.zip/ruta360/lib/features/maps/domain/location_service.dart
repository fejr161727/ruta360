import '../../../core/errors/app_failure.dart';
import '../../../core/utils/geo_utils.dart';
import '../../activities/domain/track_point.dart';

enum LocationIssue { serviceDisabled, denied, deniedForever, unavailable }

class LocationFailure extends AppFailure {
  const LocationFailure(this.issue, super.message);
  final LocationIssue issue;
}

abstract class LocationService {
  /// Obtiene la posición actual. Lanza [LocationFailure] si no es posible.
  Future<GeoPoint> currentPosition();

  /// Comprueba GPS y permiso (lo pide si hace falta). Lanza [LocationFailure].
  Future<void> ensurePermission();

  /// Posiciones continuas para grabar una actividad. En Android mantiene un
  /// servicio en primer plano con notificación mientras esté suscrito.
  Stream<TrackPoint> positionStream();

  /// Abre los ajustes del sistema apropiados para resolver [issue].
  Future<void> openSettings(LocationIssue issue);
}
