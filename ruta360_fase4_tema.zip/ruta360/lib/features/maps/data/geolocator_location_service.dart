import 'dart:async';

import 'package:geolocator/geolocator.dart';

import '../../../core/utils/geo_utils.dart';
import '../domain/location_service.dart';

class GeolocatorLocationService implements LocationService {
  const GeolocatorLocationService();

  @override
  Future<GeoPoint> currentPosition() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw const LocationFailure(
        LocationIssue.serviceDisabled,
        'El GPS está desactivado. Actívalo para ver tu ubicación.',
      );
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      throw const LocationFailure(
        LocationIssue.denied,
        'Necesitamos el permiso de ubicación para mostrarte en el mapa.',
      );
    }
    if (permission == LocationPermission.deniedForever) {
      throw const LocationFailure(
        LocationIssue.deniedForever,
        'El permiso de ubicación está bloqueado. Actívalo en los ajustes de la app.',
      );
    }

    try {
      final p = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 20),
        ),
      );
      return GeoPoint(p.latitude, p.longitude);
    } on TimeoutException {
      throw const LocationFailure(
        LocationIssue.unavailable,
        'No se pudo obtener tu ubicación a tiempo. Intenta en un lugar abierto.',
      );
    } catch (_) {
      throw const LocationFailure(
        LocationIssue.unavailable,
        'No se pudo obtener tu ubicación.',
      );
    }
  }

  @override
  Future<void> openSettings(LocationIssue issue) async {
    if (issue == LocationIssue.serviceDisabled) {
      await Geolocator.openLocationSettings();
    } else {
      await Geolocator.openAppSettings();
    }
  }
}
