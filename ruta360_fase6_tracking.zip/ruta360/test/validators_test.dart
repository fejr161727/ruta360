import 'package:flutter_test/flutter_test.dart';
import 'package:ruta360/core/utils/validators.dart';

void main() {
  group('email', () {
    test('acepta correos válidos', () {
      expect(Validators.email('fabian@ruta360.ec'), isNull);
      expect(Validators.email(' a.b+c@mail.co '), isNull);
    });
    test('rechaza vacíos e inválidos', () {
      expect(Validators.email(''), isNotNull);
      expect(Validators.email('sin-arroba'), isNotNull);
      expect(Validators.email('a@b'), isNotNull);
    });
  });

  group('contraseña', () {
    test('mínimo 8 caracteres', () {
      expect(Validators.password('1234567'), isNotNull);
      expect(Validators.password('12345678'), isNull);
    });
    test('confirmación debe coincidir', () {
      expect(Validators.confirmPassword('abc', 'abd'), isNotNull);
      expect(Validators.confirmPassword('abc', 'abc'), isNull);
    });
  });

  test('nombre mínimo 2 letras', () {
    expect(Validators.displayName('A'), isNotNull);
    expect(Validators.displayName('Fabian'), isNull);
  });
}
