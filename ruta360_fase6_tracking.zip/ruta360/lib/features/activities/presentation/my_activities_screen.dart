import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/router/app_router.dart';
import '../../../core/utils/formatters.dart';
import '../../../shared/widgets/async_error_view.dart';
import '../../../shared/widgets/empty_state.dart';
import 'activity_providers.dart';

class MyActivitiesScreen extends ConsumerWidget {
  const MyActivitiesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(myActivitiesProvider);
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Mis actividades')),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => AsyncErrorView(
            error: e, onRetry: () => ref.invalidate(myActivitiesProvider)),
        data: (list) {
          if (list.isEmpty) {
            return const EmptyState(
              icon: Icons.directions_run,
              title: 'Aún no hay actividades',
              message: 'Registra la primera desde la pestaña Registrar.',
            );
          }
          return RefreshIndicator(
            onRefresh: () async {
              ref.invalidate(myActivitiesProvider);
              await ref.read(myActivitiesProvider.future);
            },
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: list.length,
              itemBuilder: (_, i) {
                final a = list[i];
                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: scheme.primary.withOpacity(0.12),
                      child: Icon(a.type.icon, color: scheme.primary),
                    ),
                    title: Text(a.title,
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text('${Fmt.km(a.distanceMeters)} km · '
                        '${Fmt.duration(Duration(seconds: a.movingSeconds))} · '
                        '${Fmt.date(a.startedAt)}'),
                    trailing: a.visibility.id == 'private'
                        ? const Icon(Icons.lock_outline, size: 18)
                        : null,
                    onTap: () => context.push(AppRoutes.activityDetail(a.id)),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
