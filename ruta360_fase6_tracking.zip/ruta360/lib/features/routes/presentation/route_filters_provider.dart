import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/route_filters.dart';

class RouteFiltersNotifier extends Notifier<RouteFilters> {
  @override
  RouteFilters build() => const RouteFilters();

  void update(RouteFilters Function(RouteFilters current) change) {
    state = change(state);
  }

  void set(RouteFilters value) => state = value;

  void reset() => state = RouteFilters(query: state.query);
}

final routeFiltersProvider =
    NotifierProvider<RouteFiltersNotifier, RouteFilters>(
        RouteFiltersNotifier.new);
